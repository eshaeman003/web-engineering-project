using BakeCharm.Api.Models;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;

namespace BakeCharm.Api.Services;

public sealed class MongoBakeryStore
{
    private readonly IMongoDatabase _database;

    public MongoBakeryStore(IOptions<BakeCharmDatabaseSettings> options)
    {
        var client = new MongoClient(options.Value.ConnectionString);
        _database = client.GetDatabase(options.Value.DatabaseName);

        Products = _database.GetCollection<Product>("products");
        Inventory = _database.GetCollection<InventoryItem>("inventory");
        DeliverySlots = _database.GetCollection<DeliverySlot>("deliverySlots");
        Orders = _database.GetCollection<Order>("orders");
        Users = _database.GetCollection<UserAccount>("users");
        Reviews = _database.GetCollection<Review>("reviews");
        Deals = _database.GetCollection<Deal>("deals");
    }

    public IMongoCollection<Product> Products { get; }
    public IMongoCollection<InventoryItem> Inventory { get; }
    public IMongoCollection<DeliverySlot> DeliverySlots { get; }
    public IMongoCollection<Order> Orders { get; }
    public IMongoCollection<UserAccount> Users { get; }
    public IMongoCollection<Review> Reviews { get; }
    public IMongoCollection<Deal> Deals { get; }

    public async Task SeedAsync(PasswordHasher hasher, CancellationToken cancellationToken = default)
    {
        await EnsureIndexesAsync(cancellationToken);

        if (await Products.CountDocumentsAsync(FilterDefinition<Product>.Empty, cancellationToken: cancellationToken) == 0)
        {
            await Products.InsertManyAsync(SeedData.Products(), cancellationToken: cancellationToken);
        }
        else
        {
            foreach (var seededProduct in SeedData.Products())
            {
                await Products.UpdateOneAsync(
                    p => p.Name == seededProduct.Name && p.BasePrice < 500,
                    Builders<Product>.Update.Set(p => p.BasePrice, seededProduct.BasePrice),
                    cancellationToken: cancellationToken);
            }
        }

        if (await Inventory.CountDocumentsAsync(FilterDefinition<InventoryItem>.Empty, cancellationToken: cancellationToken) == 0)
        {
            await Inventory.InsertManyAsync(SeedData.Inventory(), cancellationToken: cancellationToken);
        }

        foreach (var slot in SeedData.Slots())
        {
            var existingSlot = await DeliverySlots.CountDocumentsAsync(
                s => s.Date == slot.Date && s.StartTime == slot.StartTime && s.EndTime == slot.EndTime,
                cancellationToken: cancellationToken);

            if (existingSlot == 0)
            {
                await DeliverySlots.InsertOneAsync(slot, cancellationToken: cancellationToken);
            }
        }

        if (await Deals.CountDocumentsAsync(FilterDefinition<Deal>.Empty, cancellationToken: cancellationToken) == 0)
        {
            await Deals.InsertManyAsync(SeedData.Deals(), cancellationToken: cancellationToken);
        }

        if (await Users.CountDocumentsAsync(FilterDefinition<UserAccount>.Empty, cancellationToken: cancellationToken) == 0)
        {
            await Users.InsertManyAsync(SeedData.Users(hasher), cancellationToken: cancellationToken);
        }
    }

    public async Task<List<Product>> GetProductsAsync(string? category, string? search, CancellationToken cancellationToken = default)
    {
        var filter = Builders<Product>.Filter.Eq(p => p.IsActive, true);

        if (!string.IsNullOrWhiteSpace(category) && !category.Equals("All", StringComparison.OrdinalIgnoreCase))
        {
            filter &= Builders<Product>.Filter.Eq(p => p.Category, category);
        }

        if (!string.IsNullOrWhiteSpace(search))
        {
            var regex = new BsonRegularExpression(search, "i");
            filter &= Builders<Product>.Filter.Or(
                Builders<Product>.Filter.Regex(p => p.Name, regex),
                Builders<Product>.Filter.Regex(p => p.Description, regex),
                Builders<Product>.Filter.Regex(p => p.Category, regex));
        }

        return await Products.Find(filter).SortBy(p => p.Category).ThenBy(p => p.Name).ToListAsync(cancellationToken);
    }

    public async Task<Product?> GetProductAsync(string id, CancellationToken cancellationToken = default) =>
        await Products.Find(p => p.Id == id).FirstOrDefaultAsync(cancellationToken);

    public async Task<Product> SaveProductAsync(Product product, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(product.Id))
        {
            await Products.InsertOneAsync(product, cancellationToken: cancellationToken);
            return product;
        }

        await Products.ReplaceOneAsync(p => p.Id == product.Id, product, new ReplaceOptions { IsUpsert = true }, cancellationToken);
        return product;
    }

    public async Task<List<InventoryItem>> GetInventoryAsync(CancellationToken cancellationToken = default) =>
        await Inventory.Find(FilterDefinition<InventoryItem>.Empty).SortBy(i => i.Name).ToListAsync(cancellationToken);

    public async Task<List<InventoryItem>> GetLowStockAsync(CancellationToken cancellationToken = default)
    {
        var items = await GetInventoryAsync(cancellationToken);
        return items.Where(item => item.Quantity <= item.ReorderLevel).ToList();
    }

    public async Task<InventoryItem> SaveInventoryItemAsync(InventoryItem item, CancellationToken cancellationToken = default)
    {
        item.LastUpdatedAt = DateTime.UtcNow;
        if (string.IsNullOrWhiteSpace(item.Id))
        {
            await Inventory.InsertOneAsync(item, cancellationToken: cancellationToken);
            return item;
        }

        await Inventory.ReplaceOneAsync(i => i.Id == item.Id, item, new ReplaceOptions { IsUpsert = true }, cancellationToken);
        return item;
    }

    public async Task<List<DeliverySlot>> GetSlotsAsync(string? date, CancellationToken cancellationToken = default)
    {
        var filter = FilterDefinition<DeliverySlot>.Empty;
        if (!string.IsNullOrWhiteSpace(date))
        {
            filter &= Builders<DeliverySlot>.Filter.Eq(s => s.Date, date);
        }

        return await DeliverySlots.Find(filter).SortBy(s => s.Date).ThenBy(s => s.StartTime).ToListAsync(cancellationToken);
    }

    public async Task<DeliverySlot?> ReserveSlotAsync(string slotId, CancellationToken cancellationToken = default)
    {
        var filter = Builders<DeliverySlot>.Filter.Where(s => s.Id == slotId && s.IsActive && s.BookedCount < s.Capacity);
        var update = Builders<DeliverySlot>.Update.Inc(s => s.BookedCount, 1);
        var result = await DeliverySlots.UpdateOneAsync(filter, update, cancellationToken: cancellationToken);

        return result.ModifiedCount == 0
            ? null
            : await DeliverySlots.Find(s => s.Id == slotId).FirstOrDefaultAsync(cancellationToken);
    }

    public async Task<DeliverySlot> SaveSlotAsync(DeliverySlot slot, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(slot.Id))
        {
            await DeliverySlots.InsertOneAsync(slot, cancellationToken: cancellationToken);
            return slot;
        }

        await DeliverySlots.ReplaceOneAsync(s => s.Id == slot.Id, slot, new ReplaceOptions { IsUpsert = true }, cancellationToken);
        return slot;
    }

    public async Task<Order> CreateOrderAsync(Order order, CancellationToken cancellationToken = default)
    {
        order.Timeline.Add(new OrderTimelineEvent
        {
            Status = OrderStatus.Received,
            Note = "Order received and queued for the bakery team."
        });

        await Orders.InsertOneAsync(order, cancellationToken: cancellationToken);
        await ApplyInventoryDeductionAsync(order, cancellationToken);
        await RewardCustomerAsync(order, cancellationToken);

        return order;
    }

    public async Task<List<Order>> GetOrdersAsync(string? email, OrderStatus? status, DateTime? from, DateTime? to, CancellationToken cancellationToken = default)
    {
        var filter = FilterDefinition<Order>.Empty;

        if (!string.IsNullOrWhiteSpace(email))
        {
            filter &= Builders<Order>.Filter.Eq(o => o.Email, email);
        }

        if (status.HasValue)
        {
            filter &= Builders<Order>.Filter.Eq(o => o.Status, status.Value);
        }

        if (from.HasValue)
        {
            filter &= Builders<Order>.Filter.Gte(o => o.CreatedAt, from.Value);
        }

        if (to.HasValue)
        {
            filter &= Builders<Order>.Filter.Lte(o => o.CreatedAt, to.Value);
        }

        return await Orders.Find(filter).SortByDescending(o => o.CreatedAt).ToListAsync(cancellationToken);
    }

    public async Task<Order?> GetOrderByIdAsync(string orderId, CancellationToken cancellationToken = default)
    {
        if (!ObjectId.TryParse(orderId, out _))
        {
            return null;
        }

        return await Orders.Find(o => o.Id == orderId).FirstOrDefaultAsync(cancellationToken);
    }

    public async Task<Order?> UpdateOrderStatusAsync(string orderId, OrderStatus status, string? note, CancellationToken cancellationToken = default)
    {
        var timeline = new OrderTimelineEvent
        {
            Status = status,
            Note = string.IsNullOrWhiteSpace(note) ? $"Order moved to {status}." : note
        };

        var update = Builders<Order>.Update
            .Set(o => o.Status, status)
            .Push(o => o.Timeline, timeline);

        if (status == OrderStatus.Delivered)
        {
            update = update.Set(o => o.DeliveredAt, DateTime.UtcNow);
        }

        await Orders.UpdateOneAsync(o => o.Id == orderId, update, cancellationToken: cancellationToken);
        return await Orders.Find(o => o.Id == orderId).FirstOrDefaultAsync(cancellationToken);
    }

    public async Task<Review> AddReviewAsync(Review review, CancellationToken cancellationToken = default)
    {
        await Reviews.InsertOneAsync(review, cancellationToken: cancellationToken);

        var reviews = await Reviews.Find(r => r.ProductId == review.ProductId).ToListAsync(cancellationToken);
        var rating = reviews.Count == 0 ? review.Stars : reviews.Average(r => r.Stars);
        var update = Builders<Product>.Update
            .Set(p => p.Rating, Math.Round(rating, 1))
            .Set(p => p.ReviewCount, reviews.Count);

        await Products.UpdateOneAsync(p => p.Id == review.ProductId, update, cancellationToken: cancellationToken);
        return review;
    }

    private async Task EnsureIndexesAsync(CancellationToken cancellationToken)
    {
        await Users.Indexes.CreateOneAsync(
            new CreateIndexModel<UserAccount>(
                Builders<UserAccount>.IndexKeys.Ascending(u => u.Email),
                new CreateIndexOptions { Unique = true }),
            cancellationToken: cancellationToken);

        await DeliverySlots.Indexes.CreateOneAsync(
            new CreateIndexModel<DeliverySlot>(
                Builders<DeliverySlot>.IndexKeys.Ascending(s => s.Date).Ascending(s => s.StartTime)),
            cancellationToken: cancellationToken);
    }

    private async Task ApplyInventoryDeductionAsync(Order order, CancellationToken cancellationToken)
    {
        foreach (var line in order.Items)
        {
            var product = await GetProductAsync(line.ProductId, cancellationToken);
            if (product is null)
            {
                continue;
            }

            foreach (var ingredient in product.IngredientRequirements)
            {
                var update = Builders<InventoryItem>.Update
                    .Inc(i => i.Quantity, -ingredient.Quantity * line.Quantity)
                    .Set(i => i.LastUpdatedAt, DateTime.UtcNow);

                await Inventory.UpdateOneAsync(i => i.Name == ingredient.Name, update, cancellationToken: cancellationToken);
            }
        }
    }

    private async Task RewardCustomerAsync(Order order, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(order.CustomerId) || !ObjectId.TryParse(order.CustomerId, out _))
        {
            return;
        }

        var productIds = order.Items.Select(i => i.ProductId).Where(id => !string.IsNullOrWhiteSpace(id)).Distinct().ToArray();
        var categories = new List<string>();

        foreach (var productId in productIds)
        {
            var product = await GetProductAsync(productId, cancellationToken);
            if (product is not null)
            {
                categories.Add(product.Category);
            }
        }

        var update = Builders<UserAccount>.Update
            .Inc(u => u.LoyaltyPoints, order.LoyaltyPointsEarned)
            .AddToSetEach(u => u.PreviousProductIds, productIds)
            .AddToSetEach(u => u.FavoriteCategories, categories.Distinct());

        await Users.UpdateOneAsync(u => u.Id == order.CustomerId, update, cancellationToken: cancellationToken);
    }
}
