import { useEffect, useState } from 'react';
import { Mail, ShieldCheck, UserRound, X } from 'lucide-react';
import { logoUrl } from '../../domain/constants';

export function AuthGateway({
  isOpen,
  authForm,
  setAuthForm,
  onRegister,
  onCustomerLogin,
  onAdminLogin,
  onClose
}) {
  const [mode, setMode] = useAuthMode(isOpen);

  if (!isOpen) {
    return null;
  }

  const title = mode === 'register' ? 'Create your BakeCharm account' : mode === 'login' ? 'Customer login' : 'Staff/Admin Portal';
  const submit = mode === 'register' ? onRegister : mode === 'login' ? onCustomerLogin : onAdminLogin;

  return (
    <div className="auth-overlay" role="dialog" aria-modal="true" aria-label={title}>
      <div className="auth-card-gateway">
        <button className="close-button" onClick={onClose} aria-label="Close authentication">
          <X size={18} />
        </button>

        <div className="auth-brand">
          <img src={logoUrl} alt="BakeCharm logo" />
          <div>
            <span>{mode === 'admin' ? 'Private access' : 'Welcome to'}</span>
            <h2>{title}</h2>
          </div>
        </div>

        <form onSubmit={submit} className="auth-gateway-form">
          {mode === 'register' && (
            <>
              <label>
                Name
                <input
                  className="form-control"
                  value={authForm.fullName}
                  onChange={(event) => setAuthForm((current) => ({ ...current, fullName: event.target.value }))}
                  required
                />
              </label>
              <label>
                Phone Number
                <input
                  className="form-control"
                  value={authForm.phone}
                  onChange={(event) => setAuthForm((current) => ({ ...current, phone: event.target.value }))}
                  required
                />
              </label>
            </>
          )}

          <label>
            Email
            <input
              className="form-control"
              type="email"
              value={authForm.email}
              onChange={(event) => setAuthForm((current) => ({ ...current, email: event.target.value }))}
              required
            />
          </label>

          <label>
            Password
            <input
              className="form-control"
              type="password"
              value={authForm.password}
              onChange={(event) => setAuthForm((current) => ({ ...current, password: event.target.value }))}
              required
            />
          </label>

          <button className="btn-primary-charm w-100" type="submit">
            {mode === 'admin' ? <ShieldCheck size={18} /> : mode === 'login' ? <UserRound size={18} /> : <Mail size={18} />}
            {mode === 'admin' ? 'Enter Admin Dashboard' : mode === 'login' ? 'Log In' : 'Register'}
          </button>
        </form>

        {mode === 'register' && (
          <button className="auth-text-link" onClick={() => setMode('login')}>
            Already a user? Log in.
          </button>
        )}

        {mode === 'login' && (
          <button className="auth-text-link" onClick={() => setMode('register')}>
            New here? Create an account.
          </button>
        )}

        <button className="admin-portal-link" onClick={() => setMode('admin')}>
          Staff/Admin Portal
        </button>
      </div>
    </div>
  );
}

function useAuthMode(isOpen) {
  const [mode, setMode] = useState('register');

  useEffect(() => {
    if (isOpen) {
      setMode('register');
    }
  }, [isOpen]);

  return [mode, setMode];
}
