# BakeCharm Client Handoff

This folder is a clean source-only copy of the BakeCharm Smart Bakery Management and Ordering System.

## Folder Layout

```text
BakeCharm-Complete-System/
  frontend/  React, Bootstrap, Axios, HTML, CSS, JSON, logo image
  backend/   ASP.NET Core Web API, C#, MongoDB models/services/config
  database/  MongoDB export notes, JSON exports, dump/restore scripts
  server/    setup and run instructions
```

The backend will create and seed MongoDB automatically if the database is empty. To transfer the exact database from another computer, use the scripts inside the `database` folder.

## Required Software

Install these before running the system:

1. Node.js 20 LTS or newer
2. npm, included with Node.js
3. .NET SDK 10
4. MongoDB Community Server
5. MongoDB Compass, optional, for viewing the database
6. Chrome, Edge, or another modern browser

## Database

MongoDB must be running locally at:

```text
mongodb://localhost:27017
```

Database name:

```text
BakeCharmDb
```

Collections created by the backend:

```text
products
inventory
deliverySlots
orders
users
reviews
deals
```

Database configuration is in:

```text
backend/appsettings.json
```

Database handoff instructions are in:

```text
database/README-DATABASE.md
```

## Run Backend

Open a terminal in:

```text
backend
```

Run:

```powershell
dotnet restore
dotnet run
```

Backend URL:

```text
http://localhost:5118
```

## Run Frontend

Open another terminal in:

```text
frontend
```

Run:

```powershell
npm install
npm run dev
```

Frontend URL:

```text
http://127.0.0.1:5173
```

The frontend proxies API calls to:

```text
http://localhost:5118
```

## Demo Logins

Admin:

```text
admin@bakecharm.test
Admin@12345
```

Customer:

```text
maya@bakecharm.test
Customer@12345
```

## Notes

- Do not send `node_modules`, `dist`, `bin`, or `obj` folders.
- Product photos mostly load from online image URLs.
- The local image used by the website is the logo:

```text
frontend/public/assets/bakecharm-logo.png
```
