using BakeCharm.Api.Models;

namespace BakeCharm.Api.Services;

public sealed class EmailService
{
    private readonly ILogger<EmailService> _logger;

    public EmailService(ILogger<EmailService> logger)
    {
        _logger = logger;
    }

    public Task<string> SendVerificationAsync(UserAccount user)
    {
        var message = $"Verification token for {user.Email}: {user.VerificationToken}";
        _logger.LogInformation("{Message}", message);
        return Task.FromResult(message);
    }

    public Task<string> SendOrderConfirmationAsync(Order order)
    {
        var message = $"Order confirmation sent to {order.Email} for order {order.Id}.";
        _logger.LogInformation("{Message}", message);
        return Task.FromResult(message);
    }

    public Task<int> SendPromotionAsync(IEnumerable<UserAccount> users, PromotionEmailRequest request)
    {
        var recipients = users.Where(u => u.EmailVerified).ToList();
        _logger.LogInformation("Promotion '{Subject}' queued for {Count} customers.", request.Subject, recipients.Count);
        return Task.FromResult(recipients.Count);
    }
}
