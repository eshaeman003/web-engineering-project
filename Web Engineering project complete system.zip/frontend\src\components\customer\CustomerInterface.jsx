import { useEffect, useState } from 'react';
import {
  CakeSlice,
  CreditCard,
  Facebook,
  Filter,
  Gift,
  Heart,
  Home,
  Instagram,
  LayoutDashboard,
  LogOut,
  MessageSquareText,
  MessageCircle,
  Minus,
  PackageSearch,
  Phone,
  Plus,
  Search,
  ShoppingCart,
  Sparkles,
  Star,
  Truck,
  Video,
  UserRound
} from 'lucide-react';
import { CartLine, MetricCard, StatusBadge, StatusTimeline } from '../shared/SharedUi';
import { customerReviews, logoUrl, paymentMethods } from '../../domain/constants';
import { isSlotAvailable, money } from '../../domain/helpers';

const navItems = [
  ['home', Home, 'Home'],
  ['menu', CakeSlice, 'Menu'],
  ['custom', Sparkles, 'Custom Cake'],
  ['deals', Gift, 'Deals'],
  ['reviews', MessageSquareText, 'Reviews'],
  ['track', PackageSearch, 'Track Order'],
  ['dashboard', LayoutDashboard, 'Dashboard'],
  ['cart', ShoppingCart, 'Cart'],
  ['contact', Phone, 'Contact Us']
];

export function CustomerInterface(props) {
  const {
    activeView,
    setActiveView,
    user,
    onOpenAuth,
    onLogout,
    products,
    categories,
    category,
    setCategory,
    search,
    setSearch,
    deals,
    recommendations,
    cart,
    cartTotal,
    addProductToCart,
    updateCartQuantity,
    openCustomizer,
    selectedProduct,
    custom,
    setCustom,
    customPrice,
    checkout,
    setCheckout,
    slots,
    placeOrder,
    orders,
    trackOrderId,
    setTrackOrderId,
    trackedOrder,
    trackById,
    reviewDraft,
    setReviewDraft,
    submitReview,
    postedReviews
  } = props;
  const [contactOpen, setContactOpen] = useState(false);

  return (
    <div className="interface-shell customer-shell">
      <CustomerNav
        activeView={activeView}
        setActiveView={setActiveView}
        user={user}
        cartCount={cart.length}
        onOpenAuth={onOpenAuth}
        onLogout={onLogout}
        onOpenContact={() => setContactOpen(true)}
      />

      <main className="container-fluid px-3 px-xl-4">
        {activeView === 'home' && (
          <HomeView
            user={user}
            products={products}
            deals={deals}
            recommendations={recommendations}
            setActiveView={setActiveView}
            openCustomizer={openCustomizer}
            addProductToCart={addProductToCart}
            trackOrderId={trackOrderId}
            setTrackOrderId={setTrackOrderId}
            trackById={trackById}
            postedReviews={postedReviews}
          />
        )}

        {activeView === 'menu' && (
          <MenuView
            categories={categories}
            category={category}
            setCategory={setCategory}
            search={search}
            setSearch={setSearch}
            products={products}
            addProductToCart={addProductToCart}
            openCustomizer={openCustomizer}
          />
        )}

        {activeView === 'custom' && selectedProduct && (
          <CustomizerView
            products={products.filter((product) => product.isCustomizable)}
            selectedProduct={selectedProduct}
            custom={custom}
            setCustom={setCustom}
            customPrice={customPrice}
            addProductToCart={addProductToCart}
          />
        )}

        {activeView === 'deals' && <DealsView deals={deals} products={products} addProductToCart={addProductToCart} openCustomizer={openCustomizer} />}

        {activeView === 'reviews' && (
          <ReviewsView
            products={products}
            orders={orders}
            trackedOrder={trackedOrder}
            user={user}
            postedReviews={postedReviews}
            reviewDraft={reviewDraft}
            setReviewDraft={setReviewDraft}
            submitReview={submitReview}
          />
        )}

        {activeView === 'track' && (
          <TrackOrderView
            trackOrderId={trackOrderId}
            setTrackOrderId={setTrackOrderId}
            trackById={trackById}
            trackedOrder={trackedOrder}
            user={user}
            orders={orders}
          />
        )}

        {activeView === 'dashboard' && (
          <CustomerDashboard
            user={user}
            orders={orders}
            products={products}
            reviewDraft={reviewDraft}
            setReviewDraft={setReviewDraft}
            submitReview={submitReview}
            onOpenAuth={onOpenAuth}
          />
        )}

        {activeView === 'cart' && (
          <CartAndCheckoutView
            cart={cart}
            cartTotal={cartTotal}
            checkout={checkout}
            setCheckout={setCheckout}
            slots={slots}
            placeOrder={placeOrder}
            updateCartQuantity={updateCartQuantity}
            user={user}
          />
        )}
      </main>

      <FloatingCartButton
        cart={cart}
        cartTotal={cartTotal}
        activeView={activeView}
        setActiveView={setActiveView}
      />
      <ContactModal isOpen={contactOpen} onClose={() => setContactOpen(false)} />
      <SiteFooter />
    </div>
  );
}

function CustomerNav({ activeView, setActiveView, user, cartCount, onOpenAuth, onLogout, onOpenContact }) {
  return (
    <header className="interface-nav customer-nav">
      <button className="brand-link" onClick={() => setActiveView('home')}>
        <img src={logoUrl} alt="BakeCharm logo" />
        <span>BakeCharm</span>
      </button>

      <nav className="main-nav-buttons" aria-label="Customer navigation">
        {navItems.map(([view, Icon, label]) => (
          <button
            key={view}
            className={activeView === view ? 'active' : ''}
            onClick={() => (view === 'contact' ? onOpenContact() : setActiveView(view))}
          >
            <Icon size={17} />
            <span>{label}</span>
            {view === 'cart' && cartCount > 0 && <i>{cartCount}</i>}
          </button>
        ))}
      </nav>

      <div className="auth-actions">
        {user && (
          <button className="logout-mini" onClick={onLogout} aria-label="Log out">
            <LogOut size={17} />
          </button>
        )}
        <button className="profile-icon-button" onClick={onOpenAuth} aria-label="Open authentication">
          <UserRound size={20} />
        </button>
      </div>
    </header>
  );
}

function HomeView({
  user,
  products,
  deals,
  recommendations,
  setActiveView,
  openCustomizer,
  addProductToCart,
  trackOrderId,
  setTrackOrderId,
  trackById,
  postedReviews
}) {
  const bestCake = products.find((product) => product.isCustomizable) || products[0];

  return (
    <div className="home-stack">
      <section className="hero-section">
        <img src={bestCake?.imageUrl} alt="" />
        <div className="hero-content">
          <h1>BakeCharm</h1>
          <p>Custom cakes, fresh bakes, smart delivery scheduling, and live order updates from one sweet storefront.</p>
          <div className="hero-actions">
            <button className="btn-primary-charm" onClick={() => setActiveView('menu')}>
              <ShoppingCart size={18} /> Browse Products
            </button>
            <button className="btn-soft" onClick={() => bestCake && openCustomizer(bestCake)}>
              <Sparkles size={18} /> Build a Cake
            </button>
          </div>
          <form className="hero-track-form" onSubmit={trackById}>
            <PackageSearch size={18} />
            <input
              value={trackOrderId}
              onChange={(event) => setTrackOrderId(event.target.value)}
              placeholder="Track by Order ID"
            />
            <button type="submit">Track</button>
          </form>
        </div>
      </section>

      <section className="customer-summary">
        <MetricCard icon={<ShoppingCart size={20} />} label="Open Store" value={`${products.length} items`} />
        <MetricCard icon={<Gift size={20} />} label="Active Deals" value={`${deals.length} offers`} />
        <MetricCard icon={<Heart size={20} />} label="Loyalty" value={user ? `${user.loyaltyPoints || 0} pts` : 'Login to earn'} />
      </section>

      <section className="homepage-reviews">
        <div className="section-heading">
          <h2>Customer reviews</h2>
          <button className="btn-soft" onClick={() => setActiveView('reviews')}>
            View Reviews
          </button>
        </div>
        <ReviewsCarousel postedReviews={postedReviews} />
      </section>

      <section className="home-section-panel">
        <div className="section-heading">
          <div>
            <h2>Menu highlights</h2>
            <p>Fresh picks from cakes, cupcakes, brownies, pastries, and breads.</p>
          </div>
          <button className="btn-soft" onClick={() => setActiveView('menu')}>
            View All
          </button>
        </div>
        <div className="product-grid home-product-preview">
          {products.slice(0, 4).map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              addProductToCart={addProductToCart}
              openCustomizer={openCustomizer}
            />
          ))}
        </div>
      </section>

      <section className="home-custom-section">
        <div>
          <h2>Build a cake that feels personal.</h2>
          <p>Select flavour, size, frosting, and a message. The price updates instantly before checkout.</p>
          <button className="btn-primary-charm" onClick={() => setActiveView('custom')}>
            <Sparkles size={18} /> Customize Cake
          </button>
        </div>
        <div className="custom-mini-grid">
          {(products.filter((product) => product.isCustomizable).slice(0, 3).length
            ? products.filter((product) => product.isCustomizable).slice(0, 3)
            : recommendations.slice(0, 3)
          ).map((product) => (
            <button key={product.id} onClick={() => openCustomizer(product)}>
              <img src={product.imageUrl} alt="" />
              <span>{product.name}</span>
            </button>
          ))}
        </div>
      </section>

      <section className="home-section-panel">
        <div className="section-heading">
          <div>
            <h2>Deals for today</h2>
            <p>Use active coupon codes at checkout or add a treat directly.</p>
          </div>
          <button className="btn-soft" onClick={() => setActiveView('deals')}>
            View Deals
          </button>
        </div>
        <div className="deal-strip flush">
          {deals.slice(0, 3).map((deal) => (
            <div className="deal-card" key={deal.id}>
              <Gift size={20} />
              <div>
                <strong>{deal.title}</strong>
                <span>{deal.code} saves {deal.discountPercent}%</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function MenuView({ categories, category, setCategory, search, setSearch, products, addProductToCart, openCustomizer }) {
  const filtered = products.filter((product) => {
    const term = search.trim().toLowerCase();
    const matchesCategory = category === 'All' || product.category === category;
    const matchesSearch =
      !term ||
      product.name.toLowerCase().includes(term) ||
      product.description.toLowerCase().includes(term) ||
      product.tags?.some((tag) => tag.toLowerCase().includes(term));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="view-stack">
      <div className="toolbar">
        <div className="searchbox">
          <Search size={18} />
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search cakes, cupcakes, brownies" />
        </div>
        <div className="category-tabs" role="tablist" aria-label="Product categories">
          <Filter size={17} />
          {categories.map((item) => (
            <button key={item} className={category === item ? 'active' : ''} onClick={() => setCategory(item)}>
              {item}
            </button>
          ))}
        </div>
      </div>

      <section>
        <div className="section-heading">
          <h2>Product Catalogue</h2>
          <span>{filtered.length} items</span>
        </div>
        <div className="product-grid catalogue-grid">
          {filtered.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              addProductToCart={addProductToCart}
              openCustomizer={openCustomizer}
            />
          ))}
        </div>
      </section>
    </div>
  );
}

function ProductCard({ product, addProductToCart, openCustomizer }) {
  return (
    <article className="product-card">
      <div className="product-media">
        <img src={product.imageUrl} alt={product.name} />
        <span className="tag">{product.category}</span>
      </div>
      <div className="product-body">
        <div className="product-title">
          <h3>{product.name}</h3>
          <strong>{money(product.basePrice)}</strong>
        </div>
        <p>{product.description}</p>
        <div className="rating-line">
          <Star size={16} fill="currentColor" />
          <span>{product.rating}</span>
          <span>{product.reviewCount} reviews</span>
        </div>
        <div className="tag-row">
          {product.tags?.slice(0, 3).map((tag) => (
            <span key={tag}>{tag}</span>
          ))}
        </div>
        <div className="action-row">
          {product.isCustomizable && (
            <button className="btn-soft" onClick={() => openCustomizer(product)}>
              <Sparkles size={17} /> Customize
            </button>
          )}
          <button className="btn-primary-charm" onClick={() => addProductToCart(product)}>
            <Plus size={17} /> Add
          </button>
        </div>
      </div>
    </article>
  );
}

function CustomizerView({ products, selectedProduct, custom, setCustom, customPrice, addProductToCart }) {
  const customization = {
    flavor: custom.flavor,
    size: custom.size,
    frosting: custom.frosting,
    message: custom.message,
    calculatedPrice: customPrice
  };

  return (
    <div className="customizer-layout">
      <section className="builder-panel">
        <div className="section-heading">
          <h2>Real-Time Customizer</h2>
          <span>{money(customPrice)}</span>
        </div>

        <label className="form-label">Product</label>
        <select
          className="form-select"
          value={custom.productId}
          onChange={(event) => {
            const product = products.find((item) => item.id === event.target.value);
            setCustom((current) => ({
              ...current,
              productId: event.target.value,
              flavor: product?.flavors?.[0] || current.flavor,
              size: product?.sizes?.[0] || current.size,
              frosting: product?.frostings?.[0] || current.frosting
            }));
          }}
        >
          {products.map((product) => (
            <option key={product.id} value={product.id}>{product.name}</option>
          ))}
        </select>

        <div className="builder-grid">
          <ChoiceGroup label="Cake flavour" options={selectedProduct.flavors} value={custom.flavor} onChange={(flavor) => setCustom((current) => ({ ...current, flavor }))} />
          <ChoiceGroup label="Cake size" options={selectedProduct.sizes} value={custom.size} onChange={(size) => setCustom((current) => ({ ...current, size }))} />
          <ChoiceGroup label="Frosting type" options={selectedProduct.frostings} value={custom.frosting} onChange={(frosting) => setCustom((current) => ({ ...current, frosting }))} />
        </div>

        <label className="form-label">Personalized message</label>
        <input
          className="form-control"
          value={custom.message}
          maxLength={48}
          onChange={(event) => setCustom((current) => ({ ...current, message: event.target.value }))}
        />

        <div className="quantity-row">
          <span>Quantity</span>
          <div className="stepper">
            <button onClick={() => setCustom((current) => ({ ...current, quantity: Math.max(1, current.quantity - 1) }))}>
              <Minus size={16} />
            </button>
            <strong>{custom.quantity}</strong>
            <button onClick={() => setCustom((current) => ({ ...current, quantity: current.quantity + 1 }))}>
              <Plus size={16} />
            </button>
          </div>
        </div>

        <button className="btn-primary-charm w-100" onClick={() => addProductToCart(selectedProduct, custom.quantity, customization, customPrice)}>
          <ShoppingCart size={18} /> Add Custom Cake
        </button>
      </section>

      <section className="cake-preview">
        <img src={selectedProduct.imageUrl} alt={selectedProduct.name} />
        <div className="preview-card">
          <span>{selectedProduct.name}</span>
          <h3>{custom.message || 'Your Message'}</h3>
          <p>{custom.flavor} cake, {custom.size}, {custom.frosting}</p>
          <strong>{money(customPrice * custom.quantity)}</strong>
        </div>
      </section>
    </div>
  );
}

function ChoiceGroup({ label, options = [], value, onChange }) {
  return (
    <div className="choice-group">
      <span>{label}</span>
      <div>
        {options.map((option) => (
          <button key={option} className={value === option ? 'active' : ''} onClick={() => onChange(option)}>
            {option}
          </button>
        ))}
      </div>
    </div>
  );
}

function DealsView({ deals, products, addProductToCart, openCustomizer }) {
  return (
    <div className="view-stack">
      <section className="deal-strip large">
        {deals.map((deal) => (
          <div className="deal-card" key={deal.id}>
            <Gift size={20} />
            <div>
              <strong>{deal.title}</strong>
              <span>{deal.code} saves {deal.discountPercent}%</span>
            </div>
          </div>
        ))}
      </section>
      <MenuView
        categories={['All']}
        category="All"
        setCategory={() => {}}
        search=""
        setSearch={() => {}}
        products={products.slice(0, 4)}
        addProductToCart={addProductToCart}
        openCustomizer={openCustomizer}
      />
    </div>
  );
}

function ReviewsView({ products, orders, trackedOrder, user, postedReviews, reviewDraft, setReviewDraft, submitReview }) {
  const reviewOrders = buildReviewOrders(orders, trackedOrder, user);

  return (
    <div className="view-stack reviews-page">
      <section className="review-showcase">
        <div className="section-heading">
          <div>
            <h2>Reviews</h2>
            <p>Fresh customer feedback from delivered orders.</p>
          </div>
          <span>Auto carousel</span>
        </div>
        <ReviewsCarousel postedReviews={postedReviews} />
      </section>

      <ReviewForm
        title="Post a Review"
        products={products}
        orders={reviewOrders}
        reviewDraft={reviewDraft}
        setReviewDraft={setReviewDraft}
        submitReview={submitReview}
      />
    </div>
  );
}

function ReviewsCarousel({ postedReviews = [] }) {
  const reviews = [...postedReviews, ...customerReviews].filter((review) => review.text);
  const [startIndex, setStartIndex] = useState(0);

  useEffect(() => {
    if (reviews.length <= 1) {
      return undefined;
    }

    const timer = window.setInterval(() => {
      setStartIndex((current) => (current + 1) % reviews.length);
    }, 3600);

    return () => window.clearInterval(timer);
  }, [reviews.length]);

  const visibleReviews = Array.from({ length: Math.min(reviews.length, 4) }, (_, index) => reviews[(startIndex + index) % reviews.length]);

  return (
    <div className="reviews-carousel">
      <div className="reviews-track">
        {visibleReviews.map((review, index) => (
          <article className="floating-review" key={`${review.name}-${index}`}>
            <div>
              {Array.from({ length: review.stars }).map((_, starIndex) => (
                <Star key={starIndex} size={14} fill="currentColor" />
              ))}
            </div>
            <p>{review.text}</p>
            <strong>{review.name}</strong>
          </article>
        ))}
      </div>
    </div>
  );
}

function buildReviewOrders(orders, trackedOrder, user) {
  const orderMap = new Map();

  orders.forEach((order) => {
    if (!user || order.email === user.email) {
      orderMap.set(order.id, order);
    }
  });

  if (trackedOrder) {
    orderMap.set(trackedOrder.id, trackedOrder);
  }

  return Array.from(orderMap.values());
}

function FloatingCartButton({ cart, cartTotal, activeView, setActiveView }) {
  if (cart.length === 0 || activeView === 'cart') {
    return null;
  }

  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <button className="floating-cart-button" onClick={() => setActiveView('cart')}>
      <ShoppingCart size={20} />
      <span>{itemCount} item{itemCount === 1 ? '' : 's'}</span>
      <strong>{money(cartTotal)}</strong>
    </button>
  );
}

function ContactModal({ isOpen, onClose }) {
  if (!isOpen) {
    return null;
  }

  return (
    <div className="contact-overlay" role="dialog" aria-modal="true" aria-label="Contact us">
      <form className="contact-card" onSubmit={(event) => event.preventDefault()}>
        <div className="section-heading">
          <h2>Contact Us</h2>
          <button className="btn-soft" type="button" onClick={onClose}>Close</button>
        </div>
        <label>
          Name
          <input className="form-control" required />
        </label>
        <label>
          Email
          <input className="form-control" type="email" required />
        </label>
        <label>
          Number
          <input className="form-control" required />
        </label>
        <label>
          Message
          <textarea className="form-control" required />
        </label>
        <button className="btn-primary-charm" type="submit">
          <MessageCircle size={18} /> Send Message
        </button>
      </form>
    </div>
  );
}

function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="social-links" aria-label="Social links">
        <a href="https://instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram"><Instagram size={20} /></a>
        <a href="https://facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook"><Facebook size={20} /></a>
        <a href="https://tiktok.com" target="_blank" rel="noreferrer" aria-label="TikTok"><Video size={20} /></a>
        <a href="https://wa.me/" target="_blank" rel="noreferrer" aria-label="WhatsApp"><MessageCircle size={20} /></a>
      </div>
    </footer>
  );
}

function CartAndCheckoutView({ cart, cartTotal, checkout, setCheckout, slots, placeOrder, updateCartQuantity, user }) {
  return (
    <div className="checkout-layout">
      <section className="checkout-panel">
        <div className="section-heading">
          <h2>Flexible Checkout</h2>
          <span>{user ? 'Logged-in order' : 'Guest checkout'}</span>
        </div>

        <form onSubmit={placeOrder} className="form-grid">
          <label>
            Full name
            <input className="form-control" value={checkout.name} onChange={(event) => setCheckout((current) => ({ ...current, name: event.target.value }))} required />
          </label>
          <label>
            Email
            <input className="form-control" type="email" value={checkout.email} onChange={(event) => setCheckout((current) => ({ ...current, email: event.target.value }))} required />
          </label>
          <label>
            Phone
            <input className="form-control" value={checkout.phone} onChange={(event) => setCheckout((current) => ({ ...current, phone: event.target.value }))} required />
          </label>
          <label>
            Delivery address
            <input className="form-control" value={checkout.address} onChange={(event) => setCheckout((current) => ({ ...current, address: event.target.value }))} required />
          </label>

          <div className="payment-options">
            {paymentMethods.map((method) => (
              <label key={method.value} className={checkout.paymentMethod === method.value ? 'active' : ''}>
                <input
                  type="radio"
                  name="paymentMethod"
                  checked={checkout.paymentMethod === method.value}
                  value={method.value}
                  onChange={() => setCheckout((current) => ({ ...current, paymentMethod: method.value }))}
                />
                <CreditCard size={18} />
                <strong>{method.title}</strong>
                <span>{method.description}</span>
              </label>
            ))}
          </div>

          <div className="slot-list">
            {slots.map((slot) => {
              const available = isSlotAvailable(slot);
              return (
                <label key={slot.id} className={`slot-option ${checkout.slotId === slot.id ? 'active' : ''} ${!available ? 'disabled' : ''}`}>
                  <input
                    type="radio"
                    name="slot"
                    value={slot.id}
                    disabled={!available}
                    checked={checkout.slotId === slot.id}
                    onChange={() => setCheckout((current) => ({ ...current, slotId: slot.id }))}
                  />
                  <Truck size={18} />
                  <span>{slot.date}</span>
                  <strong>{slot.startTime}-{slot.endTime}</strong>
                  <small>{slot.bookedCount}/{slot.capacity}</small>
                </label>
              );
            })}
          </div>

          <button className="btn-primary-charm" type="submit">
            <Truck size={18} /> Confirm Order
          </button>
        </form>
      </section>

      <section className="cart-review">
        <h2>Order Summary</h2>
        {cart.length === 0 && <p className="muted">Cart is empty.</p>}
        {cart.map((item) => (
          <CartLine key={item.lineId} item={item} updateCartQuantity={updateCartQuantity} />
        ))}
        <div className="total-row">
          <span>Total</span>
          <strong>{money(cartTotal)}</strong>
        </div>
      </section>
    </div>
  );
}

function TrackOrderView({
  trackOrderId,
  setTrackOrderId,
  trackById,
  trackedOrder,
  user,
  orders
}) {
  const userOrders = user ? orders.filter((order) => order.email === user.email) : [];

  return (
    <div className="view-stack">
      <section className="tracking-panel">
        <div className="section-heading">
          <h2>Track by Order ID</h2>
          <span>Guests welcome</span>
        </div>
        <form className="track-searchbar" onSubmit={trackById}>
          <PackageSearch size={19} />
          <input
            type="text"
            value={trackOrderId}
            onChange={(event) => setTrackOrderId(event.target.value)}
            placeholder="Enter your unique Order ID"
            autoComplete="off"
          />
          <button type="submit">Track</button>
        </form>
        {trackedOrder && <OrderSnapshot order={trackedOrder} />}
        <StatusTimeline order={trackedOrder} />
      </section>

      {user && (
        <section className="order-table-panel">
          <div className="section-heading">
            <h2>Your Dashboard Tracking</h2>
            <span>{userOrders.length} orders</span>
          </div>
          <OrdersTable orders={userOrders} />
        </section>
      )}

    </div>
  );
}

function CustomerDashboard({ user, orders, products, reviewDraft, setReviewDraft, submitReview, onOpenAuth }) {
  if (!user) {
    return (
      <section className="empty-state">
        <UserRound size={42} />
        <h2>Customer Dashboard</h2>
        <p>Log in from the top-right profile icon to see your personal live order progress and loyalty points.</p>
        <button className="btn-primary-charm" onClick={onOpenAuth}>Log in</button>
      </section>
    );
  }

  const userOrders = orders.filter((order) => order.email === user.email);
  const latest = userOrders[0];

  return (
    <div className="view-stack">
      <section className="tracking-panel">
        <div className="section-heading">
          <h2>{user.fullName}'s Dashboard</h2>
          <span>{user.loyaltyPoints || 0} loyalty points</span>
        </div>
        {latest && <OrderSnapshot order={latest} />}
        <StatusTimeline order={latest} />
      </section>
      <section className="order-table-panel">
        <div className="section-heading">
          <h2>My Orders</h2>
          <span>{userOrders.length}</span>
        </div>
        <OrdersTable orders={userOrders} />
      </section>
      <ReviewForm products={products} orders={userOrders} reviewDraft={reviewDraft} setReviewDraft={setReviewDraft} submitReview={submitReview} />
    </div>
  );
}

function OrderSnapshot({ order }) {
  return (
    <div className="track-meta">
      <span>{order.customerName}</span>
      <strong>{money(order.total)}</strong>
      <span>{order.deliveryWindow}</span>
      <span>{order.paymentMethod || 'CashOnDelivery'}</span>
      <StatusBadge status={order.status} />
    </div>
  );
}

function OrdersTable({ orders }) {
  return (
    <div className="responsive-table">
      <table>
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Status</th>
            <th>Total</th>
            <th>Delivery</th>
            <th>Payment</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr key={order.id}>
              <td>{order.id}</td>
              <td><StatusBadge status={order.status} /></td>
              <td>{money(order.total)}</td>
              <td>{order.deliveryWindow}</td>
              <td>{order.paymentMethod || 'COD'}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {orders.length === 0 && <p className="muted table-empty">No orders yet.</p>}
    </div>
  );
}

function ReviewForm({ title = 'Feedback', products, orders, reviewDraft, setReviewDraft, submitReview }) {
  const deliveredOrders = orders.filter((order) => order.status === 'Delivered');

  return (
    <section className="review-panel">
      <div className="section-heading">
        <div>
          <h2>{title}</h2>
          <p>Only delivered orders can receive public reviews.</p>
        </div>
        <span>{deliveredOrders.length} delivered</span>
      </div>
      <form onSubmit={submitReview} className="form-grid compact">
        <label>
          Product
          <select className="form-select" value={reviewDraft.productId} onChange={(event) => setReviewDraft((current) => ({ ...current, productId: event.target.value }))}>
            <option value="">Select product</option>
            {products.map((product) => (
              <option value={product.id} key={product.id}>{product.name}</option>
            ))}
          </select>
        </label>
        <label>
          Order
          <select className="form-select" value={reviewDraft.orderId} onChange={(event) => setReviewDraft((current) => ({ ...current, orderId: event.target.value }))}>
            <option value="">Select order</option>
            {deliveredOrders.map((order) => (
              <option value={order.id} key={order.id}>{order.id}</option>
            ))}
          </select>
        </label>
        <label>
          Stars
          <input className="form-control" type="number" min="1" max="5" value={reviewDraft.stars} onChange={(event) => setReviewDraft((current) => ({ ...current, stars: event.target.value }))} />
        </label>
        <label className="span-2">
          Review
          <input className="form-control" value={reviewDraft.comment} onChange={(event) => setReviewDraft((current) => ({ ...current, comment: event.target.value }))} />
        </label>
        <button className="btn-primary-charm" type="submit">
          <Star size={18} /> Submit Review
        </button>
      </form>
      {deliveredOrders.length === 0 && (
        <p className="muted review-helper">
          A delivered order will appear here after the admin marks it Delivered, or after you track a delivered guest order.
        </p>
      )}
    </section>
  );
}
