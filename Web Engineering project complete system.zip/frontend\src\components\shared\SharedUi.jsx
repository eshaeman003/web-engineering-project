import { CheckCircle2, Minus, Plus, X } from 'lucide-react';
import { statusLabels, statusSteps } from '../../domain/constants';
import { money } from '../../domain/helpers';

export function ToastNote({ notice }) {
  if (!notice) {
    return null;
  }

  return (
    <div className="toast-note" role="status">
      <CheckCircle2 size={18} /> {notice}
    </div>
  );
}

export function MetricCard({ icon, label, value, tone = '' }) {
  return (
    <div className={`metric-card ${tone}`}>
      <span>{icon}</span>
      <div>
        <small>{label}</small>
        <strong>{value}</strong>
      </div>
    </div>
  );
}

export function StatusBadge({ status }) {
  return <span className={`status-badge status-${status}`}>{statusLabels[status] || status}</span>;
}

export function StatusTimeline({ order }) {
  if (!order) {
    return <p className="muted">Enter an Order ID or place an order to see live tracking.</p>;
  }

  const currentIndex = Math.max(statusSteps.indexOf(order.status), 0);

  return (
    <div className="timeline">
      {statusSteps.map((status, index) => (
        <div key={status} className={index <= currentIndex ? 'done' : ''}>
          <span><CheckCircle2 size={18} /></span>
          <p>{statusLabels[status]}</p>
        </div>
      ))}
    </div>
  );
}

export function CartLine({ item, updateCartQuantity }) {
  return (
    <div className="cart-line">
      <div>
        <strong>{item.name}</strong>
        {item.customization && (
          <span>{item.customization.flavor}, {item.customization.size}</span>
        )}
        <small>{money(item.unitPrice)} each</small>
      </div>
      <div className="stepper mini">
        <button onClick={() => updateCartQuantity(item.lineId, -1)} aria-label={`Remove one ${item.name}`}>
          {item.quantity === 1 ? <X size={15} /> : <Minus size={15} />}
        </button>
        <strong>{item.quantity}</strong>
        <button onClick={() => updateCartQuantity(item.lineId, 1)} aria-label={`Add one ${item.name}`}>
          <Plus size={15} />
        </button>
      </div>
    </div>
  );
}

export function BarList({ title, rows, moneyValues = false }) {
  const max = Math.max(...rows.map((row) => Number(row.value)), 1);

  return (
    <div className="bar-list">
      <h3>{title}</h3>
      {rows.length === 0 && <p className="muted">No data yet.</p>}
      {rows.map((row) => (
        <div key={row.label} className="bar-row">
          <span>{row.label}</span>
          <div>
            <i style={{ width: `${Math.max((Number(row.value) / max) * 100, 8)}%` }} />
          </div>
          <strong>{moneyValues ? money(row.value) : row.value}</strong>
        </div>
      ))}
    </div>
  );
}
