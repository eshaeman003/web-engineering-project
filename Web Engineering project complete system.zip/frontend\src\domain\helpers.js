export function money(value) {
  return new Intl.NumberFormat('en-PK', { style: 'currency', currency: 'PKR', maximumFractionDigits: 0 }).format(Number(value || 0));
}

export function localDate() {
  return new Date().toLocaleDateString('en-CA');
}

export function isSlotAvailable(slot) {
  return Boolean(slot?.isActive) && Number(slot.bookedCount) < Number(slot.capacity);
}

export function normalizeList(value) {
  if (Array.isArray(value)) {
    return value;
  }

  return String(value || '')
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
}

export function listToInput(value) {
  return Array.isArray(value) ? value.join(', ') : value;
}

export function calculateLocalPrice(product, customization) {
  const sizeMultiplier = {
    '6 inch': 1,
    '8 inch': 1.28,
    '10 inch': 1.62,
    '12 pack': 1,
    '24 pack': 1.72
  }[customization.size] || 1;

  const frostingAddOn = {
    'Whipped Cream': 0,
    Buttercream: 500,
    'Cream Cheese': 700,
    Ganache: 900,
    'Cream Glaze': 200
  }[customization.frosting] || 0;

  const flavorAddOn = {
    Vanilla: 0,
    Chocolate: 400,
    'Red Velvet': 700,
    Strawberry: 600,
    Lemon: 300
  }[customization.flavor] || 0;

  const messageAddOn = customization.message?.trim() ? 400 : 0;
  return Number((product.basePrice * sizeMultiplier + frostingAddOn + flavorAddOn + messageAddOn).toFixed(2));
}

export function calculateAnalytics(orders, products) {
  const today = new Date().toISOString().slice(0, 10);
  const thisMonth = new Date().toISOString().slice(0, 7);
  const allItems = orders.flatMap((order) => order.items || []);
  const productLookup = new Map(products.map((product) => [product.id, product]));
  const totalRevenue = orders.reduce((sum, order) => sum + Number(order.total || 0), 0);

  const bestSellers = Array.from(
    allItems.reduce((map, item) => map.set(item.name, (map.get(item.name) || 0) + Number(item.quantity || 0)), new Map())
  )
    .map(([product, quantity]) => ({ product, quantity }))
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, 5);

  const categoryRevenue = Array.from(
    allItems.reduce((map, item) => {
      const category = productLookup.get(item.productId)?.category || 'Bakery';
      return map.set(category, (map.get(category) || 0) + Number(item.unitPrice || 0) * Number(item.quantity || 1));
    }, new Map())
  ).map(([category, revenue]) => ({ category, revenue }));

  return {
    dailyRevenue: orders
      .filter((order) => String(order.createdAt || '').slice(0, 10) === today)
      .reduce((sum, order) => sum + Number(order.total || 0), 0),
    monthlyRevenue:
      orders
        .filter((order) => String(order.createdAt || '').slice(0, 7) === thisMonth)
        .reduce((sum, order) => sum + Number(order.total || 0), 0) || totalRevenue,
    totalOrders: orders.length,
    averageOrderValue: orders.length ? totalRevenue / orders.length : 0,
    bestSellers,
    categoryRevenue,
    statusCounts: []
  };
}

export function buildRecommendations(products, orders, user) {
  const previousNames = orders
    .filter((order) => user?.email && order.email === user.email)
    .flatMap((order) => order.items || [])
    .map((item) => item.name);

  const favoriteCategories = products
    .filter((product) => previousNames.includes(product.name))
    .map((product) => product.category);

  const preferred = products
    .filter((product) => favoriteCategories.includes(product.category) || Number(product.rating) >= 4.8)
    .sort((a, b) => Number(b.rating) - Number(a.rating));

  return (preferred.length ? preferred : products).slice(0, 4);
}
