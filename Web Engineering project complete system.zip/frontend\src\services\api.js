import axios from 'axios';

export const api = axios.create({
  baseURL: '/api',
  timeout: 3500,
  headers: {
    'Content-Type': 'application/json'
  }
});

export async function safeApi(call, fallback) {
  try {
    const response = await call();
    return { data: response.data, online: true };
  } catch (error) {
    return { data: typeof fallback === 'function' ? fallback(error) : fallback, online: false, error };
  }
}
