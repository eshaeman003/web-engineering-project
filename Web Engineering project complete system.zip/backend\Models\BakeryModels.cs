using System.Text.Json.Serialization;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace BakeCharm.Api.Models;

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum UserRole
{
    Customer,
    Admin
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum OrderStatus
{
    Received,
    InProgress,
    Ready,
    OutForDelivery,
    Delivered
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum PaymentMethod
{
    CardPayment,
    OnlinePayment,
    CashOnDelivery
}

public sealed class Product
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }

    public string Name { get; set; } = "";
    public string Category { get; set; } = "";
    public string Description { get; set; } = "";
    public decimal BasePrice { get; set; }
    public string ImageUrl { get; set; } = "";
    public double Rating { get; set; }
    public int ReviewCount { get; set; }
    public bool IsCustomizable { get; set; }
    public List<string> Tags { get; set; } = [];
    public List<string> Flavors { get; set; } = [];
    public List<string> Sizes { get; set; } = [];
    public List<string> Frostings { get; set; } = [];
    public List<IngredientRequirement> IngredientRequirements { get; set; } = [];
    public bool IsActive { get; set; } = true;
}

public sealed class IngredientRequirement
{
    public string Name { get; set; } = "";
    public decimal Quantity { get; set; }
    public string Unit { get; set; } = "";
}

public sealed class InventoryItem
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }

    public string Name { get; set; } = "";
    public decimal Quantity { get; set; }
    public string Unit { get; set; } = "";
    public decimal ReorderLevel { get; set; }
    public DateTime LastUpdatedAt { get; set; } = DateTime.UtcNow;
}

public sealed class DeliverySlot
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }

    public string Date { get; set; } = "";
    public string StartTime { get; set; } = "";
    public string EndTime { get; set; } = "";
    public int Capacity { get; set; }
    public int BookedCount { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class UserAccount
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }

    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Phone { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string PasswordSalt { get; set; } = "";
    public bool EmailVerified { get; set; }
    public string VerificationToken { get; set; } = "";

    [BsonRepresentation(BsonType.String)]
    public UserRole Role { get; set; } = UserRole.Customer;

    public int LoyaltyPoints { get; set; }
    public List<string> FavoriteCategories { get; set; } = [];
    public List<string> PreviousProductIds { get; set; } = [];
    public string? ActiveToken { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public sealed class CakeCustomization
{
    public string Flavor { get; set; } = "Vanilla";
    public string Size { get; set; } = "6 inch";
    public string Frosting { get; set; } = "Whipped Cream";
    public string Message { get; set; } = "";
    public decimal CalculatedPrice { get; set; }
}

public sealed class CartLine
{
    public string ProductId { get; set; } = "";
    public string Name { get; set; } = "";
    public int Quantity { get; set; } = 1;
    public decimal UnitPrice { get; set; }
    public CakeCustomization? Customization { get; set; }
}

public sealed class Order
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }

    public string CustomerId { get; set; } = "";
    public string CustomerName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Phone { get; set; } = "";
    public string Address { get; set; } = "";
    public List<CartLine> Items { get; set; } = [];
    public string DeliverySlotId { get; set; } = "";
    public string DeliveryWindow { get; set; } = "";

    [BsonRepresentation(BsonType.String)]
    public PaymentMethod PaymentMethod { get; set; } = PaymentMethod.CashOnDelivery;

    [BsonRepresentation(BsonType.String)]
    public OrderStatus Status { get; set; } = OrderStatus.Received;

    public decimal Total { get; set; }
    public int LoyaltyPointsEarned { get; set; }
    public List<OrderTimelineEvent> Timeline { get; set; } = [];
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? DeliveredAt { get; set; }
}

public sealed class OrderTimelineEvent
{
    [BsonRepresentation(BsonType.String)]
    public OrderStatus Status { get; set; }

    public string Note { get; set; } = "";
    public DateTime At { get; set; } = DateTime.UtcNow;
}

public sealed class Review
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }

    public string ProductId { get; set; } = "";
    public string OrderId { get; set; } = "";
    public string CustomerId { get; set; } = "";
    public string CustomerName { get; set; } = "";
    public int Stars { get; set; }
    public string Comment { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public sealed class Deal
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }

    public string Title { get; set; } = "";
    public string Code { get; set; } = "";
    public decimal DiscountPercent { get; set; }
    public DateTime StartsAt { get; set; } = DateTime.UtcNow;
    public DateTime EndsAt { get; set; } = DateTime.UtcNow.AddMonths(1);
    public bool IsActive { get; set; } = true;
}

public sealed record RegisterRequest(string FullName, string Email, string Password, string Phone);
public sealed record VerifyEmailRequest(string Email, string Token);
public sealed record LoginRequest(string Email, string Password);
public sealed record PriceCalculationRequest(string ProductId, CakeCustomization Customization);
public sealed record CheckoutRequest(
    string CustomerId,
    string CustomerName,
    string Email,
    string Phone,
    string Address,
    string DeliverySlotId,
    PaymentMethod PaymentMethod,
    List<CartLine> Items);
public sealed record UpdateOrderStatusRequest(OrderStatus Status, string? Note);
public sealed record ReviewRequest(string ProductId, string OrderId, string CustomerId, string CustomerName, int Stars, string Comment);
public sealed record PromotionEmailRequest(string Subject, string Message, string? Segment);
