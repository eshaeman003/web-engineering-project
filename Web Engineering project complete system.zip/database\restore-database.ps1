$ErrorActionPreference = "Stop"

$DatabaseName = "BakeCharmDb"
$MongoUri = "mongodb://localhost:27017"
$DumpPath = Join-Path $PSScriptRoot "mongo-dump\BakeCharmDb"

if (-not (Get-Command mongorestore -ErrorAction SilentlyContinue)) {
  Write-Host "mongorestore was not found."
  Write-Host "Install MongoDB Database Tools and add them to PATH, then run this script again."
  exit 1
}

if (-not (Test-Path -LiteralPath $DumpPath)) {
  Write-Host "Database dump was not found at:"
  Write-Host $DumpPath
  Write-Host "Ask the sender to run create-dump.ps1 first, then send the updated database folder."
  exit 1
}

mongorestore --uri="$MongoUri" --db="$DatabaseName" --drop "$DumpPath"

Write-Host ""
Write-Host "Database restored:"
Write-Host $DatabaseName

