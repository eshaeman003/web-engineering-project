using BakeCharm.Api.Models;

namespace BakeCharm.Api.Services;

public sealed class PricingService
{
    private static readonly Dictionary<string, decimal> SizeMultipliers = new(StringComparer.OrdinalIgnoreCase)
    {
        ["6 inch"] = 1.00m,
        ["8 inch"] = 1.28m,
        ["10 inch"] = 1.62m,
        ["12 pack"] = 1.00m,
        ["24 pack"] = 1.72m
    };

    private static readonly Dictionary<string, decimal> FrostingAddOns = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Whipped Cream"] = 0m,
        ["Buttercream"] = 500m,
        ["Cream Cheese"] = 700m,
        ["Ganache"] = 900m,
        ["Cream Glaze"] = 200m
    };

    private static readonly Dictionary<string, decimal> FlavorAddOns = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Vanilla"] = 0m,
        ["Chocolate"] = 400m,
        ["Red Velvet"] = 700m,
        ["Strawberry"] = 600m,
        ["Lemon"] = 300m
    };

    public decimal Calculate(Product product, CakeCustomization customization)
    {
        var sizeMultiplier = SizeMultipliers.GetValueOrDefault(customization.Size, 1m);
        var frostingAddOn = FrostingAddOns.GetValueOrDefault(customization.Frosting, 0m);
        var flavorAddOn = FlavorAddOns.GetValueOrDefault(customization.Flavor, 0m);
        var messageAddOn = string.IsNullOrWhiteSpace(customization.Message) ? 0m : 400m;

        return decimal.Round((product.BasePrice * sizeMultiplier) + frostingAddOn + flavorAddOn + messageAddOn, 2);
    }
}
