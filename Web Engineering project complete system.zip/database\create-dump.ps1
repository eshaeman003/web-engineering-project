$ErrorActionPreference = "Stop"

$DatabaseName = "BakeCharmDb"
$MongoUri = "mongodb://localhost:27017"
$OutputFolder = Join-Path $PSScriptRoot "mongo-dump"

if (-not (Get-Command mongodump -ErrorAction SilentlyContinue)) {
  Write-Host "mongodump was not found."
  Write-Host "Install MongoDB Database Tools and add them to PATH, then run this script again."
  exit 1
}

if (Test-Path -LiteralPath $OutputFolder) {
  Remove-Item -LiteralPath $OutputFolder -Recurse -Force
}

New-Item -ItemType Directory -Force -Path $OutputFolder | Out-Null

mongodump --uri="$MongoUri" --db="$DatabaseName" --out="$OutputFolder"

Write-Host ""
Write-Host "Database dump created:"
Write-Host (Join-Path $OutputFolder $DatabaseName)

