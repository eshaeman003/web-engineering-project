import { useState } from 'react';
import {
  AlertTriangle,
  BarChart3,
  Brain,
  CalendarClock,
  Gift,
  Home,
  LogOut,
  Package,
  Plus,
  Send,
  ShoppingBag,
  SlidersHorizontal,
  Trash2,
  Truck
} from 'lucide-react';
import { BarList, MetricCard, StatusBadge } from '../shared/SharedUi';
import { logoUrl, statusLabels, statusSteps } from '../../domain/constants';
import { isSlotAvailable, listToInput, money } from '../../domain/helpers';

const adminNav = [
  ['dashboard', Home, 'Dashboard'],
  ['orders', ShoppingBag, 'Orders'],
  ['products', Package, 'Products'],
  ['inventory', AlertTriangle, 'Inventory'],
  ['schedule', CalendarClock, 'Schedule'],
  ['promotions', Gift, 'Promotions'],
  ['ai', Brain, 'AI Engine'],
  ['analytics', BarChart3, 'Analytics']
];

export function AdminInterface({
  adminUser,
  activeAdminView,
  setActiveAdminView,
  products,
  productDraft,
  setProductDraft,
  saveProduct,
  editProduct,
  deleteProduct,
  inventory,
  saveInventoryItem,
  lowStock,
  slots,
  slotDraft,
  setSlotDraft,
  saveSlot,
  orders,
  orderFilter,
  setOrderFilter,
  updateOrderStatus,
  analytics,
  promotion,
  setPromotion,
  sendPromotion,
  dealDraft,
  setDealDraft,
  saveDeal,
  deals,
  onLogout
}) {
  return (
    <div className="interface-shell admin-shell">
      <AdminNav
        activeAdminView={activeAdminView}
        setActiveAdminView={setActiveAdminView}
        adminUser={adminUser}
        onLogout={onLogout}
      />

      <main className="container-fluid px-3 px-xl-4 pb-5">
        {activeAdminView === 'dashboard' && (
          <AdminDashboard analytics={analytics} products={products} lowStock={lowStock} orders={orders} />
        )}
        {activeAdminView === 'orders' && (
          <AdminOrders orders={orders} orderFilter={orderFilter} setOrderFilter={setOrderFilter} updateOrderStatus={updateOrderStatus} />
        )}
        {activeAdminView === 'products' && (
          <ProductManagement
            products={products}
            productDraft={productDraft}
            setProductDraft={setProductDraft}
            saveProduct={saveProduct}
            editProduct={editProduct}
            deleteProduct={deleteProduct}
          />
        )}
        {activeAdminView === 'inventory' && (
          <InventoryManagement inventory={inventory} lowStock={lowStock} saveInventoryItem={saveInventoryItem} />
        )}
        {activeAdminView === 'schedule' && (
          <ScheduleManagement slots={slots} slotDraft={slotDraft} setSlotDraft={setSlotDraft} saveSlot={saveSlot} />
        )}
        {activeAdminView === 'promotions' && (
          <PromotionManagement
            promotion={promotion}
            setPromotion={setPromotion}
            sendPromotion={sendPromotion}
            dealDraft={dealDraft}
            setDealDraft={setDealDraft}
            saveDeal={saveDeal}
            deals={deals}
          />
        )}
        {activeAdminView === 'ai' && <AiManagement analytics={analytics} products={products} />}
        {activeAdminView === 'analytics' && <AnalyticsView analytics={analytics} />}
      </main>
    </div>
  );
}

function AdminNav({ activeAdminView, setActiveAdminView, adminUser, onLogout }) {
  return (
    <header className="interface-nav admin-nav">
      <button className="brand-link" onClick={() => setActiveAdminView('dashboard')}>
        <img src={logoUrl} alt="BakeCharm logo" />
        <span>BakeCharm</span>
      </button>

      <nav className="main-nav-buttons" aria-label="Admin navigation">
        {adminNav.map(([view, Icon, label]) => (
          <button key={view} className={activeAdminView === view ? 'active' : ''} onClick={() => setActiveAdminView(view)}>
            <Icon size={17} />
            <span>{label}</span>
          </button>
        ))}
      </nav>

      <button className="admin-user-chip" onClick={onLogout}>
        <LogOut size={17} />
        <span>{adminUser?.fullName || 'Admin'}</span>
      </button>
    </header>
  );
}

function AdminDashboard({ analytics, products, lowStock, orders }) {
  return (
    <div className="admin-grid">
      <section className="admin-panel span-2">
        <div className="section-heading">
          <h2>Owner Dashboard</h2>
          <span>Private operations</span>
        </div>
        <div className="analytics-grid">
          <MetricCard icon={<BarChart3 size={20} />} label="Daily Revenue" value={money(analytics.dailyRevenue || 0)} />
          <MetricCard icon={<BarChart3 size={20} />} label="Monthly Revenue" value={money(analytics.monthlyRevenue || 0)} />
          <MetricCard icon={<ShoppingBag size={20} />} label="Orders" value={orders.length} />
          <MetricCard icon={<AlertTriangle size={20} />} label="Low Stock" value={lowStock.length} tone={lowStock.length ? 'warn' : ''} />
        </div>
      </section>
      <section className="admin-panel">
        <div className="section-heading">
          <h2>Live Alerts</h2>
          <span>{lowStock.length}</span>
        </div>
        <div className="inventory-list">
          {lowStock.map((item) => (
            <div className="inventory-row low" key={item.id}>
              <div>
                <strong>{item.name}</strong>
                <span>{item.quantity} {item.unit} left</span>
              </div>
              <span>{item.reorderLevel}</span>
              <span>{item.unit}</span>
            </div>
          ))}
          {lowStock.length === 0 && <p className="muted">No low-stock alerts.</p>}
        </div>
      </section>
      <section className="admin-panel">
        <div className="section-heading">
          <h2>Catalogue</h2>
          <span>{products.length} products</span>
        </div>
        <BarList title="Best-selling products" rows={(analytics.bestSellers || []).map((item) => ({ label: item.product, value: item.quantity }))} />
      </section>
    </div>
  );
}

function AdminOrders({ orders, orderFilter, setOrderFilter, updateOrderStatus }) {
  const visibleOrders = orderFilter === 'All' ? orders : orders.filter((order) => order.status === orderFilter);

  return (
    <section className="admin-panel">
      <div className="section-heading">
        <h2>Live Order Tracking & Operations</h2>
        <select className="form-select slim-select" value={orderFilter} onChange={(event) => setOrderFilter(event.target.value)}>
          <option>All</option>
          {statusSteps.map((status) => (
            <option key={status} value={status}>{statusLabels[status]}</option>
          ))}
        </select>
      </div>
      <div className="responsive-table">
        <table>
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Customer</th>
              <th>Status</th>
              <th>Total</th>
              <th>Delivery</th>
              <th>Update</th>
            </tr>
          </thead>
          <tbody>
            {visibleOrders.map((order) => (
              <tr key={order.id}>
                <td>{order.id}</td>
                <td>{order.customerName}</td>
                <td><StatusBadge status={order.status} /></td>
                <td>{money(order.total)}</td>
                <td>{order.deliveryWindow}</td>
                <td>
                  <select className="form-select table-select" value={order.status} onChange={(event) => updateOrderStatus(order.id, event.target.value)}>
                    {statusSteps.map((status) => (
                      <option key={status} value={status}>{statusLabels[status]}</option>
                    ))}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function ProductManagement({ products, productDraft, setProductDraft, saveProduct, editProduct, deleteProduct }) {
  return (
    <div className="admin-grid">
      <section className="admin-panel">
        <div className="section-heading">
          <h2>{productDraft.id ? 'Edit Product' : 'Add Product'}</h2>
          <span>Catalogue</span>
        </div>
        <form onSubmit={saveProduct} className="product-form">
          <input className="form-control" placeholder="Product name" value={productDraft.name} onChange={(event) => setProductDraft((current) => ({ ...current, name: event.target.value }))} required />
          <input className="form-control" placeholder="Category" value={productDraft.category} onChange={(event) => setProductDraft((current) => ({ ...current, category: event.target.value }))} required />
          <input className="form-control" type="number" placeholder="Base price in PKR" value={productDraft.basePrice} onChange={(event) => setProductDraft((current) => ({ ...current, basePrice: event.target.value }))} required />
          <textarea className="form-control" placeholder="Description" value={productDraft.description} onChange={(event) => setProductDraft((current) => ({ ...current, description: event.target.value }))} required />
          <input className="form-control" placeholder="Image URL / product image" value={productDraft.imageUrl} onChange={(event) => setProductDraft((current) => ({ ...current, imageUrl: event.target.value }))} />
          <input className="form-control" placeholder="Sizes, comma separated" value={listToInput(productDraft.sizes)} onChange={(event) => setProductDraft((current) => ({ ...current, sizes: event.target.value }))} />
          <input className="form-control" placeholder="Flavours, comma separated" value={listToInput(productDraft.flavors)} onChange={(event) => setProductDraft((current) => ({ ...current, flavors: event.target.value }))} />
          <input className="form-control" placeholder="Frostings, comma separated" value={listToInput(productDraft.frostings)} onChange={(event) => setProductDraft((current) => ({ ...current, frostings: event.target.value }))} />
          <input className="form-control" placeholder="Tags, comma separated" value={listToInput(productDraft.tags)} onChange={(event) => setProductDraft((current) => ({ ...current, tags: event.target.value }))} />
          <select className="form-select" value={productDraft.isCustomizable ? 'yes' : 'no'} onChange={(event) => setProductDraft((current) => ({ ...current, isCustomizable: event.target.value === 'yes' }))}>
            <option value="yes">Customization option: Yes</option>
            <option value="no">Customization option: No</option>
          </select>
          <button className="btn-primary-charm" type="submit">
            <Plus size={18} /> Save Product
          </button>
        </form>
      </section>

      <section className="admin-panel">
        <div className="section-heading">
          <h2>Manage Products</h2>
          <span>{products.length}</span>
        </div>
        <div className="management-list">
          {products.map((product) => (
            <article key={product.id}>
              <img src={product.imageUrl} alt="" />
              <div>
                <strong>{product.name}</strong>
                <span>{product.category} | {money(product.basePrice)}</span>
              </div>
              <button className="btn-soft" onClick={() => editProduct(product)}>
                <SlidersHorizontal size={16} /> Edit
              </button>
              <button className="icon-danger" onClick={() => deleteProduct(product.id)} aria-label={`Remove ${product.name}`}>
                <Trash2 size={16} />
              </button>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}

function InventoryManagement({ inventory, lowStock, saveInventoryItem }) {
  return (
    <section className="admin-panel">
      <div className="section-heading">
        <h2>Inventory & Smart Alerts</h2>
        <span>{lowStock.length} low-stock alerts</span>
      </div>
      <div className="inventory-list wide">
        {inventory.map((item) => (
          <div className={`inventory-row ${Number(item.quantity) <= Number(item.reorderLevel) ? 'low' : ''}`} key={item.id}>
            <div>
              <strong>{item.name}</strong>
              <span>Reorder at {item.reorderLevel} {item.unit}</span>
            </div>
            <input type="number" value={item.quantity} onChange={(event) => saveInventoryItem(item, event.target.value)} className="form-control" />
            <span>{item.unit}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function ScheduleManagement({ slots, slotDraft, setSlotDraft, saveSlot }) {
  return (
    <div className="admin-grid">
      <section className="admin-panel">
        <div className="section-heading">
          <h2>Configure Daily Slots</h2>
          <span>Hard capacity limits</span>
        </div>
        <form onSubmit={saveSlot} className="form-grid one-col">
          <label>
            Date
            <input className="form-control" type="date" value={slotDraft.date} onChange={(event) => setSlotDraft((current) => ({ ...current, date: event.target.value }))} required />
          </label>
          <label>
            Start time
            <input className="form-control" type="time" value={slotDraft.startTime} onChange={(event) => setSlotDraft((current) => ({ ...current, startTime: event.target.value }))} required />
          </label>
          <label>
            End time
            <input className="form-control" type="time" value={slotDraft.endTime} onChange={(event) => setSlotDraft((current) => ({ ...current, endTime: event.target.value }))} required />
          </label>
          <label>
            Capacity
            <input className="form-control" type="number" min="1" value={slotDraft.capacity} onChange={(event) => setSlotDraft((current) => ({ ...current, capacity: event.target.value }))} required />
          </label>
          <button className="btn-primary-charm" type="submit">
            <CalendarClock size={18} /> Save Slot
          </button>
        </form>
      </section>

      <section className="admin-panel">
        <div className="section-heading">
          <h2>Schedule Control</h2>
          <span>{slots.length} slots</span>
        </div>
        <div className="slot-admin-list">
          {slots.map((slot) => (
            <button key={slot.id} className={!isSlotAvailable(slot) ? 'full' : ''} onClick={() => setSlotDraft(slot)}>
              <Truck size={17} />
              <span>{slot.date}</span>
              <strong>{slot.startTime}-{slot.endTime}</strong>
              <small>{slot.bookedCount}/{slot.capacity}</small>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}

function PromotionManagement({ promotion, setPromotion, sendPromotion, dealDraft, setDealDraft, saveDeal, deals }) {
  return (
    <div className="admin-grid">
      <section className="admin-panel">
        <div className="section-heading">
          <h2>Promotional Emails</h2>
          <span>Target customers</span>
        </div>
        <form onSubmit={sendPromotion} className="product-form">
          <input className="form-control" value={promotion.subject} onChange={(event) => setPromotion((current) => ({ ...current, subject: event.target.value }))} />
          <textarea className="form-control" value={promotion.message} onChange={(event) => setPromotion((current) => ({ ...current, message: event.target.value }))} />
          <select className="form-select" value={promotion.segment} onChange={(event) => setPromotion((current) => ({ ...current, segment: event.target.value }))}>
            <option>All Customers</option>
            <option>High Loyalty</option>
            <option>Birthday Buyers</option>
          </select>
          <button className="btn-primary-charm" type="submit">
            <Send size={18} /> Send Campaign
          </button>
        </form>
      </section>

      <section className="admin-panel">
        <div className="section-heading">
          <h2>Deals & Coupons</h2>
          <span>{deals.length} active</span>
        </div>
        <form onSubmit={saveDeal} className="product-form">
          <input className="form-control" placeholder="Deal title" value={dealDraft.title} onChange={(event) => setDealDraft((current) => ({ ...current, title: event.target.value }))} />
          <input className="form-control" placeholder="Coupon code" value={dealDraft.code} onChange={(event) => setDealDraft((current) => ({ ...current, code: event.target.value }))} />
          <input className="form-control" type="number" placeholder="Discount percent" value={dealDraft.discountPercent} onChange={(event) => setDealDraft((current) => ({ ...current, discountPercent: event.target.value }))} />
          <button className="btn-primary-charm" type="submit">
            <Gift size={18} /> Save Deal
          </button>
        </form>
        <div className="coupon-list">
          {deals.map((deal) => (
            <button key={deal.id} onClick={() => setDealDraft(deal)}>
              <strong>{deal.code}</strong>
              <span>{deal.title} | {deal.discountPercent}%</span>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}

function AiManagement({ analytics, products }) {
  const best = analytics.bestSellers?.[0]?.product || products[0]?.name || 'No trend yet';

  return (
    <section className="admin-panel ai-panel">
      <div className="section-heading">
        <h2>AI Recommendation Engine</h2>
        <span>Managed rules</span>
      </div>
      <div className="ai-grid">
        <div>
          <Brain size={34} />
          <h3>Recommendation priority</h3>
          <p>Blend customer history, high-rated products, and aggregated best-selling trends.</p>
        </div>
        <div>
          <strong>{best}</strong>
          <span>Current trend anchor</span>
        </div>
        <div>
          <strong>{products.filter((product) => product.isCustomizable).length}</strong>
          <span>Customizable products promoted</span>
        </div>
      </div>
      <BarList title="Trend signals" rows={(analytics.bestSellers || []).map((item) => ({ label: item.product, value: item.quantity }))} />
    </section>
  );
}

function AnalyticsView({ analytics }) {
  return (
    <section className="admin-panel">
      <div className="section-heading">
        <h2>Marketing & Analytics</h2>
        <span>Decision dashboard</span>
      </div>
      <div className="analytics-grid">
        <MetricCard icon={<BarChart3 size={20} />} label="Daily Revenue" value={money(analytics.dailyRevenue || 0)} />
        <MetricCard icon={<BarChart3 size={20} />} label="Monthly Revenue" value={money(analytics.monthlyRevenue || 0)} />
        <MetricCard icon={<ShoppingBag size={20} />} label="Total Orders" value={analytics.totalOrders || 0} />
        <MetricCard icon={<Truck size={20} />} label="Average Order" value={money(analytics.averageOrderValue || 0)} />
      </div>
      <BarList title="Best-selling products" rows={(analytics.bestSellers || []).map((item) => ({ label: item.product, value: item.quantity }))} />
      <BarList title="Revenue by category" rows={(analytics.categoryRevenue || []).map((item) => ({ label: item.category, value: Number(item.revenue) }))} moneyValues />
    </section>
  );
}
