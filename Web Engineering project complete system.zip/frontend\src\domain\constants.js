export const logoUrl = '/assets/bakecharm-logo.png';

export const statusSteps = ['Received', 'InProgress', 'Ready', 'OutForDelivery', 'Delivered'];

export const statusLabels = {
  Received: 'Received',
  InProgress: 'In Progress',
  Ready: 'Ready',
  OutForDelivery: 'Out for Delivery',
  Delivered: 'Delivered'
};

export const paymentMethods = [
  {
    value: 'CardPayment',
    title: 'Card Payment',
    description: 'Credit or debit card'
  },
  {
    value: 'OnlinePayment',
    title: 'Online Payment',
    description: 'Wallets or net banking'
  },
  {
    value: 'CashOnDelivery',
    title: 'Cash on Delivery',
    description: 'Pay when your order arrives'
  }
];

export const customerReviews = [
  {
    name: 'Maya K.',
    text: 'The custom cake builder made it so easy to get the exact birthday cake I wanted.',
    stars: 5
  },
  {
    name: 'Ali R.',
    text: 'The order ID tracking was instant, and the cupcakes arrived right in the selected slot.',
    stars: 5
  },
  {
    name: 'Sara M.',
    text: 'Fresh brownies, careful packaging, and the dashboard kept me updated the whole way.',
    stars: 4
  },
  {
    name: 'Hassan A.',
    text: 'Loved the frosting options and the delivery slot controls. Very smooth experience.',
    stars: 5
  }
];

export const defaultProductDraft = {
  name: '',
  category: 'Cakes',
  description: '',
  basePrice: 3200,
  imageUrl: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=900&q=80',
  rating: 4.8,
  reviewCount: 0,
  isCustomizable: true,
  tags: ['new'],
  flavors: ['Vanilla', 'Chocolate', 'Strawberry'],
  sizes: ['6 inch', '8 inch', '10 inch'],
  frostings: ['Whipped Cream', 'Buttercream', 'Ganache'],
  ingredientRequirements: []
};
