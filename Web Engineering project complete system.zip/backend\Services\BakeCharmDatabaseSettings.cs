namespace BakeCharm.Api.Services;

public sealed class BakeCharmDatabaseSettings
{
    public string ConnectionString { get; set; } = "mongodb://localhost:27017";
    public string DatabaseName { get; set; } = "BakeCharmDb";
}
