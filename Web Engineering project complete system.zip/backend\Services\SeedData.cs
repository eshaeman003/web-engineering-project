using BakeCharm.Api.Models;

namespace BakeCharm.Api.Services;

public static class SeedData
{
    public static List<Product> Products() =>
    [
        new()
        {
            Name = "Strawberry Cloud Cake",
            Category = "Cakes",
            Description = "Vanilla sponge, fresh strawberry filling, whipped frosting, and soft pink piping.",
            BasePrice = 4200,
            ImageUrl = "https://images.unsplash.com/photo-1621303837174-89787a7d4729?auto=format&fit=crop&w=900&q=80",
            Rating = 4.9,
            ReviewCount = 128,
            IsCustomizable = true,
            Tags = ["birthday", "custom", "best seller"],
            Flavors = ["Vanilla", "Chocolate", "Red Velvet", "Strawberry"],
            Sizes = ["6 inch", "8 inch", "10 inch"],
            Frostings = ["Whipped Cream", "Buttercream", "Cream Cheese", "Ganache"],
            IngredientRequirements =
            [
                new() { Name = "Cake Flour", Quantity = 0.65m, Unit = "kg" },
                new() { Name = "Fresh Strawberries", Quantity = 0.45m, Unit = "kg" },
                new() { Name = "Butter", Quantity = 0.35m, Unit = "kg" }
            ]
        },
        new()
        {
            Name = "Charm Cupcake Box",
            Category = "Cupcakes",
            Description = "A dozen assorted cupcakes with buttercream swirls and seasonal sprinkles.",
            BasePrice = 2800,
            ImageUrl = "https://images.unsplash.com/photo-1599785209707-a456fc1337bb?auto=format&fit=crop&w=900&q=80",
            Rating = 4.8,
            ReviewCount = 96,
            IsCustomizable = true,
            Tags = ["party", "gift"],
            Flavors = ["Vanilla", "Chocolate", "Lemon", "Strawberry"],
            Sizes = ["12 pack", "24 pack"],
            Frostings = ["Buttercream", "Cream Cheese"],
            IngredientRequirements =
            [
                new() { Name = "Cake Flour", Quantity = 0.4m, Unit = "kg" },
                new() { Name = "Butter", Quantity = 0.25m, Unit = "kg" },
                new() { Name = "Delivery Boxes", Quantity = 1, Unit = "pcs" }
            ]
        },
        new()
        {
            Name = "Fudge Brownie Slab",
            Category = "Brownies",
            Description = "Dense chocolate brownie slab with ganache glaze and toasted walnuts.",
            BasePrice = 2200,
            ImageUrl = "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=900&q=80",
            Rating = 4.7,
            ReviewCount = 75,
            IsCustomizable = false,
            Tags = ["chocolate", "quick pick"],
            Flavors = ["Chocolate"],
            Sizes = ["Classic slab"],
            Frostings = ["Ganache"],
            IngredientRequirements =
            [
                new() { Name = "Chocolate", Quantity = 0.5m, Unit = "kg" },
                new() { Name = "Butter", Quantity = 0.2m, Unit = "kg" }
            ]
        },
        new()
        {
            Name = "Macaron Celebration Tray",
            Category = "Pastries",
            Description = "Pastel macarons in raspberry, pistachio, lemon, vanilla, and mocha.",
            BasePrice = 3400,
            ImageUrl = "https://images.unsplash.com/photo-1569864358642-9d1684040f43?auto=format&fit=crop&w=900&q=80",
            Rating = 4.6,
            ReviewCount = 62,
            IsCustomizable = false,
            Tags = ["gift", "premium"],
            Flavors = ["Assorted"],
            Sizes = ["24 pack"],
            IngredientRequirements =
            [
                new() { Name = "Cake Flour", Quantity = 0.25m, Unit = "kg" },
                new() { Name = "Delivery Boxes", Quantity = 1, Unit = "pcs" }
            ]
        },
        new()
        {
            Name = "Cinnamon Morning Rolls",
            Category = "Breads",
            Description = "Soft brioche rolls with cinnamon sugar, cream glaze, and a warm finish.",
            BasePrice = 1800,
            ImageUrl = "https://images.unsplash.com/photo-1509365465985-25d11c17e812?auto=format&fit=crop&w=900&q=80",
            Rating = 4.7,
            ReviewCount = 54,
            IsCustomizable = false,
            Tags = ["breakfast", "fresh daily"],
            Flavors = ["Cinnamon"],
            Sizes = ["6 pack", "12 pack"],
            Frostings = ["Cream Glaze"],
            IngredientRequirements =
            [
                new() { Name = "Cake Flour", Quantity = 0.55m, Unit = "kg" },
                new() { Name = "Butter", Quantity = 0.2m, Unit = "kg" }
            ]
        },
        new()
        {
            Name = "Mini Tart Garden",
            Category = "Pastries",
            Description = "Buttery tart shells filled with custard and topped with berries and citrus.",
            BasePrice = 3100,
            ImageUrl = "https://images.unsplash.com/photo-1519869325930-281384150729?auto=format&fit=crop&w=900&q=80",
            Rating = 4.8,
            ReviewCount = 83,
            IsCustomizable = false,
            Tags = ["fruit", "seasonal"],
            Flavors = ["Berry", "Lemon", "Mixed Fruit"],
            Sizes = ["18 piece"],
            IngredientRequirements =
            [
                new() { Name = "Cake Flour", Quantity = 0.3m, Unit = "kg" },
                new() { Name = "Fresh Strawberries", Quantity = 0.35m, Unit = "kg" },
                new() { Name = "Delivery Boxes", Quantity = 1, Unit = "pcs" }
            ]
        }
    ];

    public static List<InventoryItem> Inventory() =>
    [
        new() { Name = "Cake Flour", Quantity = 24, Unit = "kg", ReorderLevel = 10 },
        new() { Name = "Fresh Strawberries", Quantity = 7, Unit = "kg", ReorderLevel = 8 },
        new() { Name = "Butter", Quantity = 14, Unit = "kg", ReorderLevel = 9 },
        new() { Name = "Chocolate", Quantity = 18, Unit = "kg", ReorderLevel = 7 },
        new() { Name = "Delivery Boxes", Quantity = 38, Unit = "pcs", ReorderLevel = 25 }
    ];

    public static List<DeliverySlot> Slots()
    {
        var today = BusinessDate();
        var tomorrow = today.AddDays(1);

        return
        [
            new() { Date = today.ToString("yyyy-MM-dd"), StartTime = "09:00", EndTime = "11:00", Capacity = 6, BookedCount = 2 },
            new() { Date = today.ToString("yyyy-MM-dd"), StartTime = "12:00", EndTime = "14:00", Capacity = 5, BookedCount = 5 },
            new() { Date = today.ToString("yyyy-MM-dd"), StartTime = "15:00", EndTime = "17:00", Capacity = 5, BookedCount = 3 },
            new() { Date = tomorrow.ToString("yyyy-MM-dd"), StartTime = "10:00", EndTime = "12:00", Capacity = 5, BookedCount = 1 },
            new() { Date = tomorrow.ToString("yyyy-MM-dd"), StartTime = "16:00", EndTime = "18:00", Capacity = 4, BookedCount = 0 }
        ];
    }

    public static string BusinessDateString() => BusinessDate().ToString("yyyy-MM-dd");

    private static DateTime BusinessDate()
    {
        foreach (var timeZoneId in new[] { "Pakistan Standard Time", "Asia/Karachi" })
        {
            try
            {
                var zone = TimeZoneInfo.FindSystemTimeZoneById(timeZoneId);
                return TimeZoneInfo.ConvertTime(DateTimeOffset.UtcNow, zone).Date;
            }
            catch (TimeZoneNotFoundException)
            {
            }
            catch (InvalidTimeZoneException)
            {
            }
        }

        return DateTimeOffset.Now.Date;
    }

    public static List<Deal> Deals() =>
    [
        new() { Title = "Birthday Spark", Code = "JOY15", DiscountPercent = 15, StartsAt = DateTime.UtcNow.AddDays(-2), EndsAt = DateTime.UtcNow.AddDays(30) },
        new() { Title = "Weekend Treat Box", Code = "CHARM10", DiscountPercent = 10, StartsAt = DateTime.UtcNow.AddDays(-1), EndsAt = DateTime.UtcNow.AddDays(12) }
    ];

    public static List<UserAccount> Users(PasswordHasher hasher)
    {
        var adminHash = hasher.Hash("Admin@12345", out var adminSalt);
        var customerHash = hasher.Hash("Customer@12345", out var customerSalt);

        return
        [
            new()
            {
                FullName = "BakeCharm Admin",
                Email = "admin@bakecharm.test",
                Phone = "+1 555 0100",
                PasswordHash = adminHash,
                PasswordSalt = adminSalt,
                EmailVerified = true,
                VerificationToken = "verified",
                Role = UserRole.Admin,
                LoyaltyPoints = 0
            },
            new()
            {
                FullName = "Maya Khan",
                Email = "maya@bakecharm.test",
                Phone = "+1 555 0101",
                PasswordHash = customerHash,
                PasswordSalt = customerSalt,
                EmailVerified = true,
                VerificationToken = "verified",
                Role = UserRole.Customer,
                LoyaltyPoints = 142,
                FavoriteCategories = ["Cakes", "Cupcakes"]
            }
        ];
    }
}
