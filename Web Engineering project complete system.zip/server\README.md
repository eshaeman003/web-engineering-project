# BakeCharm Smart Bakery Management and Ordering System

BakeCharm is a full-stack bakery ordering platform built with React, Bootstrap, Axios, JSON data, ASP.NET Core Web API, C#, and MongoDB.

## What is included

- Customer account flow with email verification and secure password hashing on the API.
- Product catalogue with categories, filters, ratings, pricing, recommendations, and reviews.
- Custom cake builder with real-time price calculation through an API endpoint and client fallback.
- Cart and checkout with delivery-slot capacity validation.
- Order creation, inventory deduction, loyalty points, and order-status tracking.
- Admin dashboard for products, inventory, delivery slots, promotions, orders, and analytics.
- MongoDB-backed API with seeded demo data for first run.
- React frontend that gracefully falls back to local demo JSON if the API is offline.

## Project structure

```text
Bakecharm/
  client/                  React + Bootstrap frontend
  server/BakeCharm.Api/    ASP.NET Core Web API + MongoDB
```

## Run the API

1. Make sure MongoDB is running locally on `mongodb://localhost:27017`.
2. From `server/BakeCharm.Api`, run:

```bash
dotnet restore
dotnet run
```

The API listens on `http://localhost:5118` by default.

## Run the frontend

From `client`, run:

```bash
npm install
npm run dev
```

Open the Vite URL, usually `http://localhost:5173`.

## Demo accounts

- Admin: `admin@bakecharm.test` / `Admin@12345`
- Customer: `maya@bakecharm.test` / `Customer@12345`

Email delivery is simulated in the API response/logs so the project can be demonstrated without SMTP setup.
