# BakeCharm Database Handoff

The live MongoDB database is not a normal project file. It must be exported from MongoDB and restored on the client's computer.

## Database Details

Connection string used by the backend:

```text
mongodb://localhost:27017
```

Database name:

```text
BakeCharmDb
```

Collections:

```text
products
inventory
deliverySlots
orders
users
reviews
deals
```

## Best Way To Share The Database

Use MongoDB Database Tools:

```text
mongodump
mongorestore
```

These tools are separate from MongoDB Compass. If they are not installed, download and install MongoDB Database Tools, then add the tools folder to PATH.

## Create A Database Dump

On the original computer, run this from the `database` folder:

```powershell
.\create-dump.ps1
```

This creates:

```text
database\mongo-dump\BakeCharmDb
```

That folder contains the real MongoDB `.bson` database dump.

## Restore On Client Computer

On the client's computer:

1. Install MongoDB Community Server.
2. Start MongoDB.
3. Open a terminal in the `database` folder.
4. Run:

```powershell
.\restore-database.ps1
```

This restores the database as:

```text
BakeCharmDb
```

## JSON Export Folder

This package also includes:

```text
database\json-export
```

These JSON files are exported from the API for reference:

```text
products.json
inventory.json
deliverySlots.json
orders.json
deals.json
reviews.json
```

The JSON exports are useful for checking data, but the best complete database transfer is the `mongodump` folder because it preserves MongoDB documents more accurately.

## Important Note

The backend can create and seed a new database automatically if MongoDB is empty. So even without a dump, the client can run the backend and it will create initial demo data.

