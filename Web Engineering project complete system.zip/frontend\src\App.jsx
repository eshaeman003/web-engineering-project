import { useEffect, useMemo, useState } from 'react';
import { api, safeApi } from './services/api';
import demoData from './data/demoData.json';
import { AuthGateway } from './components/auth/AuthGateway';
import { CustomerInterface } from './components/customer/CustomerInterface';
import { AdminInterface } from './components/admin/AdminInterface';
import { ToastNote } from './components/shared/SharedUi';
import { defaultProductDraft } from './domain/constants';
import {
  buildRecommendations,
  calculateAnalytics,
  calculateLocalPrice,
  isSlotAvailable,
  localDate,
  normalizeList
} from './domain/helpers';

const defaultCheckout = {
  name: '',
  email: '',
  phone: '',
  address: '',
  slotId: '',
  paymentMethod: 'CashOnDelivery'
};

const defaultAuthForm = {
  fullName: '',
  email: '',
  password: '',
  phone: ''
};

const defaultSlotDraft = {
  date: localDate(),
  startTime: '09:00',
  endTime: '11:00',
  capacity: 4,
  bookedCount: 0,
  isActive: true
};

const defaultDealDraft = {
  title: '',
  code: '',
  discountPercent: 10,
  isActive: true
};

function App() {
  const [interfaceMode, setInterfaceMode] = useState('customer');
  const [activeView, setActiveView] = useState('home');
  const [activeAdminView, setActiveAdminView] = useState('dashboard');
  const [products, setProducts] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [slots, setSlots] = useState([]);
  const [orders, setOrders] = useState([]);
  const [deals, setDeals] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [demoMode, setDemoMode] = useState(false);
  const [notice, setNotice] = useState('');
  const [user, setUser] = useState(null);
  const [adminUser, setAdminUser] = useState(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [authForm, setAuthForm] = useState(defaultAuthForm);
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState([]);
  const [checkout, setCheckout] = useState(defaultCheckout);
  const [custom, setCustom] = useState({
    productId: '',
    flavor: 'Vanilla',
    size: '6 inch',
    frosting: 'Whipped Cream',
    message: 'Happy Birthday',
    quantity: 1
  });
  const [customPrice, setCustomPrice] = useState(0);
  const [trackOrderId, setTrackOrderId] = useState('');
  const [trackedOrder, setTrackedOrder] = useState(null);
  const [reviewDraft, setReviewDraft] = useState({ productId: '', orderId: '', stars: 5, comment: '' });
  const [postedReviews, setPostedReviews] = useState([]);
  const [orderFilter, setOrderFilter] = useState('All');
  const [productDraft, setProductDraft] = useState(defaultProductDraft);
  const [slotDraft, setSlotDraft] = useState(defaultSlotDraft);
  const [dealDraft, setDealDraft] = useState(defaultDealDraft);
  const [promotion, setPromotion] = useState({
    subject: 'A fresh BakeCharm treat is waiting',
    message: 'Enjoy this week with a charming bakery offer.',
    segment: 'All Customers'
  });

  useEffect(() => {
    loadSystem();
  }, []);

  useEffect(() => {
    const firstCustom = products.find((product) => product.isCustomizable);
    if (firstCustom && !custom.productId) {
      setCustom((current) => ({
        ...current,
        productId: firstCustom.id,
        flavor: firstCustom.flavors?.[0] || current.flavor,
        size: firstCustom.sizes?.[0] || current.size,
        frosting: firstCustom.frostings?.[0] || current.frosting
      }));
    }
  }, [products, custom.productId]);

  useEffect(() => {
    if (!checkout.slotId && slots.length > 0) {
      const firstOpenSlot = slots.find(isSlotAvailable);
      if (firstOpenSlot) {
        setCheckout((current) => ({ ...current, slotId: firstOpenSlot.id }));
      }
    }
  }, [slots, checkout.slotId]);

  useEffect(() => {
    if (user) {
      setCheckout((current) => ({
        ...current,
        name: current.name || user.fullName,
        email: current.email || user.email,
        phone: current.phone || user.phone || ''
      }));
    }
  }, [user]);

  const selectedProduct = useMemo(
    () => products.find((product) => product.id === custom.productId) || products.find((product) => product.isCustomizable),
    [products, custom.productId]
  );

  useEffect(() => {
    if (!selectedProduct) {
      return undefined;
    }

    const timer = window.setTimeout(async () => {
      const customization = {
        flavor: custom.flavor,
        size: custom.size,
        frosting: custom.frosting,
        message: custom.message,
        calculatedPrice: 0
      };

      const result = await safeApi(
        () => api.post(`/products/${selectedProduct.id}/price`, { productId: selectedProduct.id, customization }),
        () => ({ price: calculateLocalPrice(selectedProduct, customization), customization })
      );

      setCustomPrice(Number(result.data?.price ?? calculateLocalPrice(selectedProduct, customization)));
    }, 180);

    return () => window.clearTimeout(timer);
  }, [selectedProduct, custom.flavor, custom.size, custom.frosting, custom.message]);

  const categories = useMemo(() => ['All', ...new Set(products.map((product) => product.category))], [products]);
  const cartTotal = cart.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const lowStock = inventory.filter((item) => Number(item.quantity) <= Number(item.reorderLevel));
  const currentAnalytics = analytics || calculateAnalytics(orders, products);
  const recommendations = useMemo(() => buildRecommendations(products, orders, user), [products, orders, user]);

  async function loadSystem() {
    const [productResult, inventoryResult, slotResult, orderResult, dealResult, reviewResult, analyticsResult] = await Promise.all([
      safeApi(() => api.get('/products'), demoData.products),
      safeApi(() => api.get('/inventory'), demoData.inventory),
      safeApi(() => api.get('/delivery-slots', { params: { date: localDate() } }), demoData.slots),
      safeApi(() => api.get('/orders'), demoData.orders),
      safeApi(() => api.get('/deals'), demoData.deals),
      safeApi(() => api.get('/reviews'), []),
      safeApi(() => api.get('/analytics'), () => calculateAnalytics(demoData.orders, demoData.products))
    ]);

    setDemoMode(!productResult.online);
    setProducts(normalizePkrProducts(productResult.data));
    setInventory(inventoryResult.data);
    setSlots(slotResult.data.length ? slotResult.data : demoData.slots);
    setOrders(normalizePkrOrders(orderResult.data));
    setDeals(dealResult.data);
    setPostedReviews(normalizeReviews(reviewResult.data));
    setAnalytics(analyticsResult.data);
  }

  function showNotice(message) {
    setNotice(message);
    window.setTimeout(() => setNotice(''), 4200);
  }

  async function handleRegister(event) {
    event.preventDefault();
    const result = await safeApi(
      () => api.post('/auth/register', authForm),
      () => ({
        id: 'demo-customer',
        fullName: authForm.fullName,
        email: authForm.email,
        phone: authForm.phone,
        emailVerified: false,
        verificationMessage: 'Demo verification email sent.'
      })
    );

    showNotice(result.data.verificationMessage || 'Verification email sent.');
  }

  async function handleCustomerLogin(event) {
    event.preventDefault();
    const result = await safeApi(
      () => api.post('/auth/login', { email: authForm.email, password: authForm.password }),
      () => ({
        token: 'demo-customer-token',
        user: {
          id: 'demo-customer',
          fullName: authForm.fullName || 'BakeCharm Customer',
          email: authForm.email || 'guest@bakecharm.test',
          phone: authForm.phone,
          role: 'Customer',
          loyaltyPoints: 142,
          favoriteCategories: ['Cakes', 'Cupcakes']
        }
      })
    );

    if (result.data.user.role === 'Admin') {
      showNotice('Use the Staff/Admin Portal link for admin access.');
      return;
    }

    setUser(result.data.user);
    setAuthOpen(false);
    showNotice(result.online ? 'Customer login successful.' : 'Demo customer login active.');
  }

  async function handleAdminLogin(event) {
    event.preventDefault();
    const result = await safeApi(
      () => api.post('/auth/login', { email: authForm.email, password: authForm.password }),
      () => {
        const isAdmin = authForm.email.toLowerCase().includes('admin');
        if (!isAdmin) {
          return {
            token: 'demo-customer-token',
            user: {
              id: 'demo-customer',
              fullName: authForm.fullName || 'BakeCharm Customer',
              email: authForm.email,
              role: 'Customer',
              loyaltyPoints: 0
            }
          };
        }
        return {
          token: 'demo-admin-token',
          user: {
            id: 'demo-admin',
            fullName: 'BakeCharm Admin',
            email: authForm.email,
            role: 'Admin',
            loyaltyPoints: 0
          }
        };
      }
    );

    if (result.data?.user?.role !== 'Admin') {
      showNotice('These credentials are not authorized for the admin dashboard.');
      return;
    }

    setAdminUser(result.data.user);
    setAuthOpen(false);
    setInterfaceMode('admin');
    setActiveAdminView('dashboard');
    showNotice('Admin dashboard unlocked.');
  }

  function handleLogout() {
    setUser(null);
    setAdminUser(null);
    setInterfaceMode('customer');
    setActiveView('home');
    showNotice('Signed out.');
  }

  function openCustomizer(product) {
    setCustom((current) => ({
      ...current,
      productId: product.id,
      flavor: product.flavors?.[0] || current.flavor,
      size: product.sizes?.[0] || current.size,
      frosting: product.frostings?.[0] || current.frosting
    }));
    setActiveView('custom');
  }

  function addProductToCart(product, quantity = 1, customization = null, overridePrice = null) {
    const signature = customization
      ? `${product.id}-${customization.flavor}-${customization.size}-${customization.frosting}-${customization.message}`
      : product.id;
    const lineId = `${signature}`.replace(/\s+/g, '-').toLowerCase();
    const unitPrice = Number(overridePrice ?? product.basePrice);

    setCart((current) => {
      const existing = current.find((item) => item.lineId === lineId);
      if (existing) {
        return current.map((item) => (item.lineId === lineId ? { ...item, quantity: item.quantity + quantity } : item));
      }

      return [
        ...current,
        {
          lineId,
          productId: product.id,
          name: product.name,
          quantity,
          unitPrice,
          customization
        }
      ];
    });

    showNotice(`${product.name} added to cart.`);
  }

  function updateCartQuantity(lineId, amount) {
    setCart((current) =>
      current
        .map((item) => (item.lineId === lineId ? { ...item, quantity: Math.max(0, item.quantity + amount) } : item))
        .filter((item) => item.quantity > 0)
    );
  }

  async function placeOrder(event) {
    event.preventDefault();

    if (cart.length === 0) {
      showNotice('Your cart is empty.');
      return;
    }

    const slot = slots.find((item) => item.id === checkout.slotId);
    if (!slot || !isSlotAvailable(slot)) {
      showNotice('Please select an available delivery slot.');
      return;
    }

    const payload = {
      customerId: user?.id || '',
      customerName: checkout.name,
      email: checkout.email,
      phone: checkout.phone,
      address: checkout.address,
      deliverySlotId: checkout.slotId,
      paymentMethod: checkout.paymentMethod,
      items: cart.map(({ lineId, ...line }) => line)
    };

    const result = await safeApi(
      () => api.post('/orders', payload),
      () => {
        const order = {
          id: `demo-${Date.now()}`,
          customerId: payload.customerId,
          customerName: payload.customerName,
          email: payload.email,
          phone: payload.phone,
          address: payload.address,
          items: payload.items,
          deliverySlotId: slot.id,
          deliveryWindow: `${slot.date}, ${slot.startTime}-${slot.endTime}`,
          paymentMethod: payload.paymentMethod,
          status: 'Received',
          total: cartTotal,
          loyaltyPointsEarned: user ? Math.floor(cartTotal) : 0,
          createdAt: new Date().toISOString(),
          timeline: [{ status: 'Received', note: 'Order received.', at: new Date().toISOString() }]
        };
        return { order, confirmation: `Order confirmation sent to ${payload.email}.` };
      }
    );

    const createdOrder = result.data.order;
    setOrders((current) => [createdOrder, ...current]);
    setTrackedOrder(createdOrder);
    setTrackOrderId(createdOrder.id);
    setSlots((current) => current.map((item) => (item.id === slot.id ? { ...item, bookedCount: item.bookedCount + 1 } : item)));
    setInventory((current) =>
      current.map((item) => ({
        ...item,
        quantity: item.name === 'Fresh Strawberries' ? Math.max(0, Number(item.quantity) - 0.5) : item.quantity
      }))
    );
    setCart([]);
    setActiveView('track');
    showNotice(result.data.confirmation || 'Order confirmed.');
  }

  async function trackById(event) {
    event.preventDefault();
    const id = trackOrderId.trim();
    if (!id) {
      showNotice('Enter an Order ID to track.');
      return;
    }

    const result = await safeApi(
      () => api.get(`/orders/${id}`),
      () => orders.find((order) => order.id === id) || null
    );

    if (!result.data) {
      showNotice('No order found for that ID.');
      return;
    }

    setTrackedOrder(result.data);
    setActiveView('track');
  }

  async function submitReview(event) {
    event.preventDefault();
    const order = orders.find((item) => item.id === reviewDraft.orderId) || (trackedOrder?.id === reviewDraft.orderId ? trackedOrder : null);
    const product = products.find((item) => item.id === reviewDraft.productId);

    if (!product || !order) {
      showNotice('Choose a product and order to review.');
      return;
    }

    if (order.status !== 'Delivered') {
      showNotice('Reviews unlock after the order is delivered.');
      return;
    }

    if (!reviewDraft.comment.trim()) {
      showNotice('Write a short review before submitting.');
      return;
    }

    const reviewPayload = {
      productId: reviewDraft.productId,
      orderId: reviewDraft.orderId,
      customerId: user?.id || '',
      customerName: user?.fullName || order.customerName,
      stars: Number(reviewDraft.stars),
      comment: reviewDraft.comment.trim()
    };

    const result = await safeApi(
      () => api.post('/reviews', reviewPayload),
      () => ({ ...reviewPayload, id: `local-review-${Date.now()}`, createdAt: new Date().toISOString() })
    );

    setProducts((current) =>
      current.map((item) =>
        item.id === product.id
          ? {
              ...item,
              rating: Number(((item.rating * item.reviewCount + Number(reviewDraft.stars)) / (item.reviewCount + 1)).toFixed(1)),
              reviewCount: item.reviewCount + 1
            }
          : item
      )
    );
    setPostedReviews((current) => [normalizeReview(result.data), ...current]);
    setReviewDraft({ productId: '', orderId: '', stars: 5, comment: '' });
    showNotice('Review submitted.');
  }

  async function updateOrderStatus(orderId, status) {
    const result = await safeApi(
      () => api.patch(`/orders/${orderId}/status`, { status, note: 'Updated from admin dashboard.' }),
      () => {
        const order = orders.find((item) => item.id === orderId);
        return {
          ...order,
          status,
          timeline: [...(order?.timeline || []), { status, note: 'Updated from admin dashboard.', at: new Date().toISOString() }]
        };
      }
    );

    setOrders((current) => current.map((order) => (order.id === orderId ? result.data : order)));
    setTrackedOrder((current) => (current?.id === orderId ? result.data : current));
  }

  async function saveProduct(event) {
    event.preventDefault();
    const payload = {
      ...productDraft,
      basePrice: Number(productDraft.basePrice),
      rating: Number(productDraft.rating || 4.8),
      reviewCount: Number(productDraft.reviewCount || 0),
      tags: normalizeList(productDraft.tags),
      flavors: normalizeList(productDraft.flavors),
      sizes: normalizeList(productDraft.sizes),
      frostings: normalizeList(productDraft.frostings),
      isCustomizable: Boolean(productDraft.isCustomizable)
    };

    const result = await safeApi(
      () => (payload.id ? api.put(`/products/${payload.id}`, payload) : api.post('/products', payload)),
      () => ({ ...payload, id: payload.id || `demo-product-${Date.now()}` })
    );

    setProducts((current) => {
      const exists = current.some((product) => product.id === result.data.id);
      return exists ? current.map((product) => (product.id === result.data.id ? result.data : product)) : [result.data, ...current];
    });
    setProductDraft(defaultProductDraft);
    showNotice('Product saved.');
  }

  function editProduct(product) {
    setProductDraft(product);
  }

  async function deleteProduct(productId) {
    await safeApi(() => api.delete(`/products/${productId}`), () => ({ ok: true }));
    setProducts((current) => current.filter((product) => product.id !== productId));
    showNotice('Product removed.');
  }

  async function saveInventoryItem(item, nextQuantity) {
    const payload = { ...item, quantity: Number(nextQuantity) };
    const result = await safeApi(() => api.post('/inventory', payload), () => payload);
    setInventory((current) => current.map((entry) => (entry.id === item.id ? result.data : entry)));
  }

  async function saveSlot(event) {
    event.preventDefault();
    const payload = {
      ...slotDraft,
      capacity: Number(slotDraft.capacity),
      bookedCount: Number(slotDraft.bookedCount || 0),
      isActive: true
    };
    const result = await safeApi(() => api.post('/delivery-slots', payload), () => ({ ...payload, id: payload.id || `demo-slot-${Date.now()}` }));
    setSlots((current) => {
      const exists = current.some((slot) => slot.id === result.data.id);
      return exists ? current.map((slot) => (slot.id === result.data.id ? result.data : slot)) : [...current, result.data];
    });
    setSlotDraft(defaultSlotDraft);
    showNotice('Delivery slot saved.');
  }

  async function saveDeal(event) {
    event.preventDefault();
    const payload = {
      ...dealDraft,
      discountPercent: Number(dealDraft.discountPercent),
      isActive: true
    };
    const result = await safeApi(() => api.post('/deals', payload), () => ({ ...payload, id: payload.id || `demo-deal-${Date.now()}` }));
    setDeals((current) => {
      const exists = current.some((deal) => deal.id === result.data.id);
      return exists ? current.map((deal) => (deal.id === result.data.id ? result.data : deal)) : [result.data, ...current];
    });
    setDealDraft(defaultDealDraft);
    showNotice('Deal saved.');
  }

  async function sendPromotion(event) {
    event.preventDefault();
    const result = await safeApi(
      () => api.post('/promotions/email', promotion),
      () => ({ queued: 24, message: 'Promotion queued for 24 verified customers.' })
    );
    showNotice(result.data.message);
  }

  return (
    <>
      <ToastNote notice={notice} />
      <AuthGateway
        isOpen={authOpen}
        authForm={authForm}
        setAuthForm={setAuthForm}
        onRegister={handleRegister}
        onCustomerLogin={handleCustomerLogin}
        onAdminLogin={handleAdminLogin}
        onClose={() => setAuthOpen(false)}
      />

      {interfaceMode === 'customer' ? (
        <CustomerInterface
          activeView={activeView}
          setActiveView={setActiveView}
          user={user}
          onOpenAuth={() => setAuthOpen(true)}
          onLogout={handleLogout}
          products={products}
          categories={categories}
          category={category}
          setCategory={setCategory}
          search={search}
          setSearch={setSearch}
          deals={deals}
          recommendations={recommendations}
          cart={cart}
          cartTotal={cartTotal}
          addProductToCart={addProductToCart}
          updateCartQuantity={updateCartQuantity}
          openCustomizer={openCustomizer}
          selectedProduct={selectedProduct}
          custom={custom}
          setCustom={setCustom}
          customPrice={customPrice}
          checkout={checkout}
          setCheckout={setCheckout}
          slots={slots}
          placeOrder={placeOrder}
          orders={orders}
          trackOrderId={trackOrderId}
          setTrackOrderId={setTrackOrderId}
          trackedOrder={trackedOrder}
          trackById={trackById}
          reviewDraft={reviewDraft}
          setReviewDraft={setReviewDraft}
          submitReview={submitReview}
          postedReviews={postedReviews}
          demoMode={demoMode}
        />
      ) : (
        <AdminInterface
          adminUser={adminUser}
          activeAdminView={activeAdminView}
          setActiveAdminView={setActiveAdminView}
          products={products}
          productDraft={productDraft}
          setProductDraft={setProductDraft}
          saveProduct={saveProduct}
          editProduct={editProduct}
          deleteProduct={deleteProduct}
          inventory={inventory}
          saveInventoryItem={saveInventoryItem}
          lowStock={lowStock}
          slots={slots}
          slotDraft={slotDraft}
          setSlotDraft={setSlotDraft}
          saveSlot={saveSlot}
          orders={orders}
          orderFilter={orderFilter}
          setOrderFilter={setOrderFilter}
          updateOrderStatus={updateOrderStatus}
          analytics={currentAnalytics}
          promotion={promotion}
          setPromotion={setPromotion}
          sendPromotion={sendPromotion}
          dealDraft={dealDraft}
          setDealDraft={setDealDraft}
          saveDeal={saveDeal}
          deals={deals}
          onLogout={handleLogout}
        />
      )}
    </>
  );
}

function normalizePkrProducts(products) {
  return products.map((product) => ({
    ...product,
    basePrice: Number(product.basePrice) > 0 && Number(product.basePrice) < 500 ? Number(product.basePrice) * 100 : Number(product.basePrice)
  }));
}

function normalizePkrOrders(orders) {
  return orders.map((order) => ({
    ...order,
    total: Number(order.total) > 0 && Number(order.total) < 500 ? Number(order.total) * 100 : Number(order.total),
    items: (order.items || []).map((item) => ({
      ...item,
      unitPrice: Number(item.unitPrice) > 0 && Number(item.unitPrice) < 500 ? Number(item.unitPrice) * 100 : Number(item.unitPrice)
    }))
  }));
}

function normalizeReview(review) {
  return {
    ...review,
    name: review.customerName || review.name || 'BakeCharm Customer',
    text: review.comment || review.text || '',
    stars: Number(review.stars || 5)
  };
}

function normalizeReviews(reviews) {
  return Array.isArray(reviews) ? reviews.map(normalizeReview).filter((review) => review.text.trim()) : [];
}

export default App;
