using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;
using BakeCharm.Api.Models;
using BakeCharm.Api.Services;
using MongoDB.Driver;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<BakeCharmDatabaseSettings>(
    builder.Configuration.GetSection("BakeCharmDatabase"));

builder.Services.AddSingleton<MongoBakeryStore>();
builder.Services.AddSingleton<PasswordHasher>();
builder.Services.AddSingleton<PricingService>();
builder.Services.AddSingleton<EmailService>();

builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    options.SerializerOptions.Converters.Add(new JsonStringEnumConverter());
});

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.WithOrigins("http://localhost:5173", "http://127.0.0.1:5173")
            .AllowAnyHeader()
            .AllowAnyMethod());
});

var app = builder.Build();

app.UseCors();

using (var scope = app.Services.CreateScope())
{
    var store = scope.ServiceProvider.GetRequiredService<MongoBakeryStore>();
    var hasher = scope.ServiceProvider.GetRequiredService<PasswordHasher>();
    await store.SeedAsync(hasher);
}

app.MapGet("/api/health", () => Results.Ok(new
{
    status = "healthy",
    system = "BakeCharm Smart Bakery API",
    checkedAt = DateTime.UtcNow
}));

app.MapPost("/api/auth/register", async (
    RegisterRequest request,
    MongoBakeryStore store,
    PasswordHasher hasher,
    EmailService emailService,
    CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Phone) || request.Password.Length < 8)
    {
        return Results.BadRequest(new { message = "Name, email, phone, and an 8+ character password are required." });
    }

    var existing = await store.Users.Find(u => u.Email == request.Email.ToLowerInvariant()).FirstOrDefaultAsync(cancellationToken);
    if (existing is not null)
    {
        return Results.Conflict(new { message = "An account already exists for this email." });
    }

    var passwordHash = hasher.Hash(request.Password, out var salt);
    var user = new UserAccount
    {
        FullName = request.FullName,
        Email = request.Email.ToLowerInvariant(),
        Phone = request.Phone,
        PasswordHash = passwordHash,
        PasswordSalt = salt,
        VerificationToken = RandomToken()
    };

    await store.Users.InsertOneAsync(user, cancellationToken: cancellationToken);
    var verificationMessage = await emailService.SendVerificationAsync(user);

    return Results.Created($"/api/users/{user.Id}", new
    {
        user.Id,
            user.FullName,
            user.Email,
            user.Phone,
            user.EmailVerified,
            verificationMessage
    });
});

app.MapPost("/api/auth/verify-email", async (
    VerifyEmailRequest request,
    MongoBakeryStore store,
    CancellationToken cancellationToken) =>
{
    var update = Builders<UserAccount>.Update
        .Set(u => u.EmailVerified, true)
        .Set(u => u.VerificationToken, "verified");

    var result = await store.Users.UpdateOneAsync(
        u => u.Email == request.Email.ToLowerInvariant() && u.VerificationToken == request.Token,
        update,
        cancellationToken: cancellationToken);

    return result.ModifiedCount == 0
        ? Results.BadRequest(new { message = "Invalid verification token." })
        : Results.Ok(new { message = "Email verified successfully." });
});

app.MapPost("/api/auth/login", async (
    LoginRequest request,
    MongoBakeryStore store,
    PasswordHasher hasher,
    CancellationToken cancellationToken) =>
{
    var user = await store.Users.Find(u => u.Email == request.Email.ToLowerInvariant()).FirstOrDefaultAsync(cancellationToken);
    if (user is null || !hasher.Verify(request.Password, user.PasswordSalt, user.PasswordHash))
    {
        return Results.Unauthorized();
    }

    if (!user.EmailVerified)
    {
        return Results.BadRequest(new { message = "Please verify your email before logging in." });
    }

    user.ActiveToken = RandomToken();
    await store.Users.ReplaceOneAsync(u => u.Id == user.Id, user, cancellationToken: cancellationToken);

    return Results.Ok(new
    {
        token = user.ActiveToken,
        user = new
        {
            user.Id,
            user.FullName,
            user.Email,
            user.Phone,
            user.Role,
            user.LoyaltyPoints,
            user.FavoriteCategories
        }
    });
});

app.MapGet("/api/products", async (
    string? category,
    string? search,
    MongoBakeryStore store,
    CancellationToken cancellationToken) =>
{
    var products = await store.GetProductsAsync(category, search, cancellationToken);
    return Results.Ok(products);
});

app.MapGet("/api/products/{id}", async (string id, MongoBakeryStore store, CancellationToken cancellationToken) =>
{
    var product = await store.GetProductAsync(id, cancellationToken);
    return product is null ? Results.NotFound() : Results.Ok(product);
});

app.MapPost("/api/products", async (Product product, MongoBakeryStore store, CancellationToken cancellationToken) =>
{
    var saved = await store.SaveProductAsync(product, cancellationToken);
    return Results.Ok(saved);
});

app.MapPut("/api/products/{id}", async (string id, Product product, MongoBakeryStore store, CancellationToken cancellationToken) =>
{
    product.Id = id;
    var saved = await store.SaveProductAsync(product, cancellationToken);
    return Results.Ok(saved);
});

app.MapDelete("/api/products/{id}", async (string id, MongoBakeryStore store, CancellationToken cancellationToken) =>
{
    var result = await store.Products.DeleteOneAsync(p => p.Id == id, cancellationToken);
    return result.DeletedCount == 0 ? Results.NotFound() : Results.NoContent();
});

app.MapPost("/api/products/{id}/price", async (
    string id,
    PriceCalculationRequest request,
    MongoBakeryStore store,
    PricingService pricing,
    CancellationToken cancellationToken) =>
{
    var product = await store.GetProductAsync(id, cancellationToken);
    if (product is null)
    {
        return Results.NotFound(new { message = "Product not found." });
    }

    var price = pricing.Calculate(product, request.Customization);
    request.Customization.CalculatedPrice = price;

    return Results.Ok(new { price, customization = request.Customization });
});

app.MapGet("/api/inventory", async (MongoBakeryStore store, CancellationToken cancellationToken) =>
    Results.Ok(await store.GetInventoryAsync(cancellationToken)));

app.MapGet("/api/inventory/low-stock", async (MongoBakeryStore store, CancellationToken cancellationToken) =>
    Results.Ok(await store.GetLowStockAsync(cancellationToken)));

app.MapPost("/api/inventory", async (InventoryItem item, MongoBakeryStore store, CancellationToken cancellationToken) =>
    Results.Ok(await store.SaveInventoryItemAsync(item, cancellationToken)));

app.MapGet("/api/delivery-slots", async (string? date, MongoBakeryStore store, CancellationToken cancellationToken) =>
    Results.Ok(await store.GetSlotsAsync(date, cancellationToken)));

app.MapPost("/api/delivery-slots", async (DeliverySlot slot, MongoBakeryStore store, CancellationToken cancellationToken) =>
    Results.Ok(await store.SaveSlotAsync(slot, cancellationToken)));

app.MapGet("/api/deals", async (MongoBakeryStore store, CancellationToken cancellationToken) =>
    Results.Ok(await store.Deals.Find(d => d.IsActive).ToListAsync(cancellationToken)));

app.MapPost("/api/deals", async (Deal deal, MongoBakeryStore store, CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(deal.Id))
    {
        await store.Deals.InsertOneAsync(deal, cancellationToken: cancellationToken);
    }
    else
    {
        await store.Deals.ReplaceOneAsync(d => d.Id == deal.Id, deal, new ReplaceOptions { IsUpsert = true }, cancellationToken);
    }

    return Results.Ok(deal);
});

app.MapPost("/api/orders", async (
    CheckoutRequest request,
    MongoBakeryStore store,
    PricingService pricing,
    EmailService emailService,
    CancellationToken cancellationToken) =>
{
    if (request.Items.Count == 0)
    {
        return Results.BadRequest(new { message = "Cart is empty." });
    }

    var slot = await store.ReserveSlotAsync(request.DeliverySlotId, cancellationToken);
    if (slot is null)
    {
        return Results.Conflict(new { message = "Selected delivery slot is no longer available." });
    }

    var order = new Order
    {
        CustomerId = request.CustomerId,
        CustomerName = request.CustomerName,
        Email = request.Email.ToLowerInvariant(),
        Phone = request.Phone,
        Address = request.Address,
        DeliverySlotId = slot.Id ?? "",
        DeliveryWindow = $"{slot.Date}, {slot.StartTime}-{slot.EndTime}",
        PaymentMethod = request.PaymentMethod,
        Items = request.Items
    };

    foreach (var line in order.Items)
    {
        var product = await store.GetProductAsync(line.ProductId, cancellationToken);
        if (product is null)
        {
            continue;
        }

        line.Name = product.Name;
        line.UnitPrice = line.Customization is null ? product.BasePrice : pricing.Calculate(product, line.Customization);
        if (line.Customization is not null)
        {
            line.Customization.CalculatedPrice = line.UnitPrice;
        }
    }

    order.Total = order.Items.Sum(item => item.UnitPrice * item.Quantity);
    order.LoyaltyPointsEarned = (int)Math.Floor(order.Total);

    await store.CreateOrderAsync(order, cancellationToken);
    var confirmation = await emailService.SendOrderConfirmationAsync(order);

    return Results.Created($"/api/orders/{order.Id}", new { order, confirmation });
});

app.MapGet("/api/orders", async (
    string? email,
    OrderStatus? status,
    DateTime? from,
    DateTime? to,
    MongoBakeryStore store,
    CancellationToken cancellationToken) =>
{
    var orders = await store.GetOrdersAsync(email, status, from, to, cancellationToken);
    return Results.Ok(orders);
});

app.MapGet("/api/orders/{id}", async (
    string id,
    MongoBakeryStore store,
    CancellationToken cancellationToken) =>
{
    var order = await store.GetOrderByIdAsync(id, cancellationToken);
    return order is null ? Results.NotFound(new { message = "Order ID not found." }) : Results.Ok(order);
});

app.MapPatch("/api/orders/{id}/status", async (
    string id,
    UpdateOrderStatusRequest request,
    MongoBakeryStore store,
    CancellationToken cancellationToken) =>
{
    var order = await store.UpdateOrderStatusAsync(id, request.Status, request.Note, cancellationToken);
    return order is null ? Results.NotFound() : Results.Ok(order);
});

app.MapGet("/api/reviews", async (MongoBakeryStore store, CancellationToken cancellationToken) =>
{
    var reviews = await store.Reviews
        .Find(_ => true)
        .SortByDescending(review => review.CreatedAt)
        .Limit(24)
        .ToListAsync(cancellationToken);

    return Results.Ok(reviews);
});

app.MapPost("/api/reviews", async (
    ReviewRequest request,
    MongoBakeryStore store,
    CancellationToken cancellationToken) =>
{
    if (request.Stars is < 1 or > 5)
    {
        return Results.BadRequest(new { message = "Stars must be between 1 and 5." });
    }

    var review = new Review
    {
        ProductId = request.ProductId,
        OrderId = request.OrderId,
        CustomerId = request.CustomerId,
        CustomerName = request.CustomerName,
        Stars = request.Stars,
        Comment = request.Comment
    };

    return Results.Ok(await store.AddReviewAsync(review, cancellationToken));
});

app.MapGet("/api/recommendations/{email}", async (
    string email,
    MongoBakeryStore store,
    CancellationToken cancellationToken) =>
{
    var user = await store.Users.Find(u => u.Email == email.ToLowerInvariant()).FirstOrDefaultAsync(cancellationToken);
    var products = await store.GetProductsAsync(null, null, cancellationToken);

    if (user is null || user.FavoriteCategories.Count == 0)
    {
        return Results.Ok(products.OrderByDescending(p => p.Rating).Take(3));
    }

    var recommendations = products
        .Where(p => user.FavoriteCategories.Contains(p.Category) && !user.PreviousProductIds.Contains(p.Id ?? ""))
        .OrderByDescending(p => p.Rating)
        .Take(4)
        .ToList();

    return Results.Ok(recommendations.Count == 0 ? products.OrderByDescending(p => p.Rating).Take(3) : recommendations);
});

app.MapGet("/api/analytics", async (MongoBakeryStore store, CancellationToken cancellationToken) =>
{
    var orders = await store.GetOrdersAsync(null, null, null, null, cancellationToken);
    var products = await store.GetProductsAsync(null, null, cancellationToken);
    var today = DateTime.UtcNow.Date;
    var month = new DateTime(today.Year, today.Month, 1);

    var itemCounts = orders
        .SelectMany(order => order.Items)
        .GroupBy(item => item.Name)
        .Select(group => new { product = group.Key, quantity = group.Sum(item => item.Quantity) })
        .OrderByDescending(item => item.quantity)
        .Take(5)
        .ToList();

    var categoryRevenue = orders
        .SelectMany(order => order.Items)
        .Join(products, item => item.ProductId, product => product.Id, (item, product) => new { product.Category, revenue = item.UnitPrice * item.Quantity })
        .GroupBy(row => row.Category)
        .Select(group => new { category = group.Key, revenue = group.Sum(row => row.revenue) })
        .OrderByDescending(row => row.revenue)
        .ToList();

    return Results.Ok(new
    {
        dailyRevenue = orders.Where(o => o.CreatedAt.Date == today).Sum(o => o.Total),
        monthlyRevenue = orders.Where(o => o.CreatedAt >= month).Sum(o => o.Total),
        totalOrders = orders.Count,
        averageOrderValue = orders.Count == 0 ? 0 : decimal.Round(orders.Average(o => o.Total), 2),
        bestSellers = itemCounts,
        categoryRevenue,
        statusCounts = orders.GroupBy(o => o.Status).Select(g => new { status = g.Key, count = g.Count() })
    });
});

app.MapPost("/api/promotions/email", async (
    PromotionEmailRequest request,
    MongoBakeryStore store,
    EmailService emailService,
    CancellationToken cancellationToken) =>
{
    var users = await store.Users.Find(u => u.Role == UserRole.Customer).ToListAsync(cancellationToken);
    var queued = await emailService.SendPromotionAsync(users, request);
    return Results.Ok(new { queued, message = $"Promotion queued for {queued} verified customers." });
});

app.Run();

static string RandomToken() =>
    Convert.ToHexString(RandomNumberGenerator.GetBytes(16)).ToLowerInvariant();
